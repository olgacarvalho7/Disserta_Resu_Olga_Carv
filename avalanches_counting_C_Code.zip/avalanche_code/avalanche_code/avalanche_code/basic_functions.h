//
//  basic_functions.h
//  avalanche_code
//
//  Created by Olga Carvalho on 07/01/2022.
//  Copyright © 2022 Olga Carvalho. All rights reserved.
//

#ifndef basic_functions_h
#define basic_functions_h

#include <stdio.h>

int count_nodes (char *filename);
void read_edges_directed (char *filename, int N, int **bond_in, int **bond_out);
void make_network_symmetric (int N, int **bond_in, int **bond_out);


int random_selection_from_set (int *set);
void add_to_set (int *set, int *positions, int element);
void remove_from_set (int *set, int *positions, int element);


int find_neighbor(int i, int j, int **bond);



double largest_eigenvalue (int N, int **bond);
double single_iteration (int N, int **bond, double *vec, double *vec_old);
double normalize_vector (int N, double *vec);
double estimate_error (int N, double *vec1, double *vec2);
void init_vector (int N, double *vec);


double largest_nonbacktracking (int N, int **bond);
double single_iteration_nonback(int N, int **bond, double *vec, double *vec_tmp);


#endif /* basic_functions_h */
