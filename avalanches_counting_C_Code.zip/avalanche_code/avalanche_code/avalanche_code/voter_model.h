//
//  voter_model.h
//  avalanche_code
//
//  Created by Olga Carvalho on 07/01/2022.
//  Copyright © 2022 Olga Carvalho. All rights reserved.
//

#ifndef voter_model_h
#define voter_model_h

#include <stdio.h>
void initial_reset_network_directed_VOTER (int N, int *state, int *infected, int *pos_infected, int *frontier, int *pos_frontier);
void init_state_network_directed_VOTER (int N, int **bond_in, int **bond_out,  int node, int *state, int *infected, int *pos_infected, int *frontier, int *pos_frontier);
void multiple_simulations_directed_VOTER (int N, int **bond_in, int **bond_out, double MAX_Lifetime, int T, double **results);
void single_step_directed_VOTER (int N, int **bond_in, int **bond_out, int *state, int *infected, int *pos_infected, int *frontier, int *pos_frontier, double *results);

#endif /* voter_model_h */
