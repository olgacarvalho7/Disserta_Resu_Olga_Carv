//
//  link_dynamics.c
//  avalanche_code
//
//  Created by Olga Carvalho on 07/01/2022.
//  Copyright © 2022 Olga Carvalho. All rights reserved.
//

#include "link_dynamics.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>
#include <time.h>
#include "mt64.h"
#include "basic_functions.h"




void initial_reset_network_directed_LINK_DYNAMICS (int N, int *state_nodes, int M, int *state_links, int *infected_links, int *pos_infected_links, int *frontier_links, int *pos_frontier_links)
{

  int j;

  /////////
  for(j=1;j<=N;j++) state_nodes[j] = 0;
  
  for(j=1;j<=M;j++)
  {
      state_links[j] = 0;
      infected_links[j] = -1;
      pos_infected_links[j] = -1;
      frontier_links[j] = -1;
      pos_frontier_links[j] = -1;
    }
  infected_links[0] = 0;
  frontier_links[0] = 0;
  ///////
  
}


void init_state_network_directed_LINK_DYNAMICS (int N, int **bond_in, int **bond_out, int node, int *state_nodes, int M, int *state_links, int *infected_links, int *pos_infected_links, int *frontier_links, int *pos_frontier_links, int **links, int **bond_in_to_links, int **bond_out_to_links)
{

  int j, q, n, m;
  
  while(infected_links[0]>0)
    {
      q = infected_links[1];
      n = links[q][0];
      m = links[q][1];
      remove_from_set (infected_links, pos_infected_links, q);
      state_links[q] = 0;
      state_nodes[n] = 0;
      state_nodes[m] = 0;
    }

  while(frontier_links[0]>0)
    {
      q = frontier_links[1];
      n = links[q][0];
      m = links[q][1];
      remove_from_set (frontier_links, pos_frontier_links, q);
      state_links[q] = 0;
      state_nodes[n] = 0;
      state_nodes[m] = 0;
    }



  

  state_nodes[node] = 1;

  
  for(j=1;j<=bond_out[0][node];j++)
    {

      
      n = bond_out[node][j];
      q = bond_out_to_links[node][j];

      
      if(state_nodes[n]==1){
    add_to_set (infected_links, pos_infected_links, q);
    state_links[q] = 1;
      }
      
      if(state_nodes[n]==0){
    add_to_set (frontier_links, pos_frontier_links, q);
    state_links[q] = 2;
      }
      
    }


  
  
  for(j=1;j<=bond_in[0][node];j++)
    {


      n = bond_in[node][j];
      q = bond_in_to_links[node][j];
      
      if(state_nodes[n] == 1){
    add_to_set (infected_links, pos_infected_links, q);
    state_links[q] = 1;
      }
      
      if(state_nodes[n] == 0){
    add_to_set (frontier_links, pos_frontier_links, q);
    state_links[q] = 3;
      }
      
    }
  

}

/////////



void multiple_simulations_directed_LINK_DYNAMICS (int N, int **bond_in, int **bond_out, double MAX_Lifetime, int T, double **results)
{

  int t, i, j, k;

  int M = 0;
  for(i=1;i<=N;i++) M += bond_out[0][i];

  //memory allocation
  int *state_nodes = (int *)malloc((N+1)*sizeof(int));
  //
  int *state_links = (int *)malloc((M+1)*sizeof(int));
  int *infected_links = (int *)malloc((M+1)*sizeof(int));
  int *pos_infected_links = (int *)malloc((M+1)*sizeof(int));
  int *frontier_links = (int *)malloc((M+1)*sizeof(int));
  int *pos_frontier_links = (int *)malloc((M+1)*sizeof(int));
  int **links = (int **)malloc((M+1)*sizeof(int *));
  for(i=1;i<=M;i++) links[i] = (int *)malloc(2*sizeof(int));
  int **bond_out_to_links = (int **)malloc((N+1)*sizeof(int *));
  int **bond_in_to_links = (int **)malloc((N+1)*sizeof(int *));
  bond_out_to_links[0] = (int *)malloc((N+1)*sizeof(int));
  bond_in_to_links[0] = (int *)malloc((N+1)*sizeof(int));
  for(i=1;i<=N;i++)
    {
      bond_out_to_links[0][i] = bond_out[0][i];
      bond_out_to_links[i] = (int *)malloc((bond_out[0][i]+1)*sizeof(int));
      bond_in_to_links[0][i] = bond_in[0][i];
      bond_in_to_links[i] = (int *)malloc((bond_in[0][i]+1)*sizeof(int));
    }
    //

  //
  M = 0;
  for(i=1;i<=N;i++)
    {
      for(j=1;j<=bond_out[0][i];j++)
    {
      M ++;
      t = bond_out[i][j];
      
      links[M][0] = i;
      links[M][1] = t;
      
      bond_out_to_links[i][j] = M;
      
      k = find_neighbor(t, i, bond_in);
      bond_in_to_links[t][k] = M;


    }
      
    }
  ///////////

 


  initial_reset_network_directed_LINK_DYNAMICS (N, state_nodes, M, state_links, infected_links, pos_infected_links, frontier_links, pos_frontier_links);
  

  int r_node, control;
  int kk = 0;
  for(t=1;t<=T;t++)
    {



      if(t>kk)
        {
          printf("%d of %d\n",t,T); fflush(stdout);
          kk += (int)(0.05*(double)T);
        }




    again:
      r_node = (int)(genrand64_real3()*(double)N)+1;
      if(r_node > N) r_node = 1;
      if(bond_out[0][r_node]==0 || bond_in[0][r_node]==0) goto again;


    

      init_state_network_directed_LINK_DYNAMICS (N, bond_in, bond_out, r_node, state_nodes, M, state_links, infected_links, pos_infected_links, frontier_links, pos_frontier_links, links, bond_in_to_links, bond_out_to_links);


      //printf("# %d %d\n",r_node,infected_links[0]+frontier_links[0]);
      
      
  

      results[t][0] = 1.0;
      results[t][1] = 0.0;
      results[t][2] = 0.0;


      control = -1;

      while(control< 0 &&  (infected_links[0]+frontier_links[0]) > 0 && results[t][1] < MAX_Lifetime)
    {

      

      
      single_step_directed_LINK_DYNAMICS (N, bond_in, bond_out, state_nodes, M, state_links, infected_links, pos_infected_links, frontier_links, pos_frontier_links, links, bond_in_to_links, bond_out_to_links, results[t]);



      if(infected_links[0] == M)
        {
          control = 100;
          results[t][0] = -results[t][0];
        }

    }

    }



  
  //memory release
  free(state_nodes);
  free(state_links);
  free(infected_links);
  free(pos_infected_links);
  free(frontier_links);
  free(pos_frontier_links);
  for(i=1;i<=M;i++) free(links[i]);
  free(links);
  for(i=0;i<=N;i++) free(bond_out_to_links[i]);
  free(bond_out_to_links);
  for(i=0;i<=N;i++) free(bond_in_to_links[i]);
  free(bond_in_to_links);
  //

}

void single_step_directed_LINK_DYNAMICS (int N, int **bond_in, int **bond_out, int *state_nodes, int M, int *state_links, int *infected_links, int *pos_infected_links, int *frontier_links, int *pos_frontier_links, int **links, int **bond_in_to_links, int **bond_out_to_links, double *results)
{

  double norm, rate1, rate2;
  rate1 = (double)infected_links[0];
  rate2 = (double)frontier_links[0];
  norm = rate1 + rate2;


  results[1] -= log(genrand64_real3()) / norm;
  results[2] += (double)(ceil(log(1.0-genrand64_real3()) / log(1.0-norm/(double)M))) / (double)M;


  double p = genrand64_real3();
 
  int edge, m, n, i, q;

  ///////////////////////////
  if (p <= rate1 / norm)
    {
            
      edge =  random_selection_from_set (infected_links);
     
      results[0] += 1.0;
      
    }




  ///////////////////////////
  if (p > rate1 / norm)
    {

      edge =  random_selection_from_set (frontier_links);

      n = links[edge][0];
      m = links[edge][1];

      if(state_nodes[n] == 1 && state_nodes[m] == 0 && state_links[edge] == 2)
    {
     
      results[0] += 1.0;
      state_nodes[m] = 1;
      
      
      //updates
      for(i=1;i<=bond_out[0][m];i++)
        {
          q = bond_out_to_links[m][i];
          if (state_links[q] == 3)
        {
          remove_from_set(frontier_links, pos_frontier_links, q);
          add_to_set(infected_links, pos_infected_links, q);
          state_links[q] = 1;
        }
          if (state_links[q] == 0)
        {
          add_to_set(frontier_links, pos_frontier_links, q);
          state_links[q] = 2;
        }
        }


      for(i=1;i<=bond_in[0][m];i++)
        {
          q = bond_in_to_links[m][i];
          if (state_links[q] == 2)
        {
          remove_from_set(frontier_links, pos_frontier_links, q);
          add_to_set(infected_links, pos_infected_links, q);
          state_links[q] = 1;
        }
          if (state_links[q] == 0)
        {
          add_to_set(frontier_links, pos_frontier_links, q);
          state_links[q] = 3;
        }
        }

      
      
    }

      /////////////

       if(state_nodes[n] == 0 && state_nodes[m] == 1 && state_links[edge] == 3)
    {
     
      
      state_nodes[m] = 0;
      

      
      //updates
      for(i=1;i<=bond_out[0][m];i++)
        {
          q = bond_out_to_links[m][i];
          if (state_links[q] == 1)
        {
          remove_from_set(infected_links, pos_infected_links, q);
          add_to_set(frontier_links, pos_frontier_links, q);
          state_links[q] = 3;
        }
          if (state_links[q] == 2)
        {
          remove_from_set(frontier_links, pos_frontier_links, q);
          state_links[q] = 0;
        }
        }

      for(i=1;i<=bond_in[0][m];i++)
        {
          q = bond_in_to_links[m][i];
          if (state_links[q] == 1)
        {
          remove_from_set(infected_links, pos_infected_links, q);
          add_to_set(frontier_links, pos_frontier_links, q);
          state_links[q] = 2;
        }
          if (state_links[q] == 3)
        {
          remove_from_set(frontier_links, pos_frontier_links, q);
          state_links[q] = 0;
        }
        }
      
    }
      
      
    }




}
