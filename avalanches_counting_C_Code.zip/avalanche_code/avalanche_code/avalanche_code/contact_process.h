//
//  contact_process.h
//  avalanche_code
//
//  Created by Olga Carvalho on 07/01/2022.
//  Copyright © 2022 Olga Carvalho. All rights reserved.
//

#ifndef contact_process_h
#define contact_process_h

#include <stdio.h>

void initial_reset_network_directed_COP (int N, int *state, int *infected, int *pos_infected);
void init_state_network_directed_COP (int N, int **bond_out, int node, int *state, int *infected, int *pos_infected);
void multiple_simulations_directed_COP (int N, int **bond_in, int **bond_out, double lambda, double MAX_Lifetime, int T, double **results);
void single_step_directed_COP (int N, int **bond_out, double lambda, int *state, int *infected, int *pos_infected, double *results);

#endif /* contact_process_h */
