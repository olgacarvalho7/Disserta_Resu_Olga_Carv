//
//  BFDP.c
//  avalanche_code
//
//  Created by Olga Carvalho on 26/01/2022.
//  Copyright © 2022 Olga Carvalho. All rights reserved.
//

#include "BFDP.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>
#include <time.h>
#include "mt64.h"
#include "basic_functions.h"
#include <stdlib.h>

//The code is for a DIGRAPH
//N: number of nodes in the network
//T: number of iteractions
//node: new seed node for computing all the connected nodes
//K: must always be 1 and will count the number of nodes in the respective avalanche with doubles
//bond_in: indegree nodes
//bond_out: outdegree nodes
//connec_nodes: array to store the avanlache nodes from a seed node
//KK:cumulated number of the outdegrees in the respective avalanche
//dist_out: number of nodes in a given outdegree path
//dist_in: number of nodes in a given indegree path
//connec_nodes_nDoubles: array to store the avanlache nodes from a seed node with no duplicates
//void all_connected_nodes ( int K, int N,int T, int node, int **bond_in, int **bond_out, int *connec_nodes, int *nodes_degrees, int KK,  int *dist_out,  int *dist_in)

void avalanche (int *K, int N,int T, int *snode, int **bond_in, int **bond_out, int *connec_nodes, int *nodes_degrees, int KK,  int *dist_out,  int *dist_in, int *connec_bool, int *Pos_connec)
{
    //printf("Here1" );
    //printf("\n");
    //int nodeInd = *node;
    int k = 0;
   //int stop = 0;
   // int  addK = *K;
   // int Pos_connec = 0;
   //int P_add = 0;
   // int Ki = *K;
    
   // if( *Pos_connec > 58700 ){
    
       // printf("BEF K %d, %d",  *node, *Pos_connec  );
       // printf("\n");
   // }

   if( *Pos_connec > 0 ){ *snode = connec_nodes[*K]; }
    
   // if( *Pos_connec > 58700 ){

         //printf("BEF K %d, %d",  *node,*Pos_connec  );
         //printf("\n");
    // }
    
   // }
    //int value = *K;
    //the OutDegree of nodes
    //bond_out[0][k] is the outdegree of k node e.g node 1 has outdegree 7
    
    for (k=0; k<N+1 ; k++ ){
         dist_out[k] = 0;
         dist_out[1] =0;
        if(k==0){
            nodes_degrees[k] = 0;}
        else{
            nodes_degrees[k] = bond_out[0][k] ;}
        }
    
     //Pos_connec = k+KK-1;
    //Pos_connec = KK-1;Previous
    //Pos_connec = KK;
   // if(connec_bool[node] == 1) { //PREVIOUS
      // KK -=bond_out[0][node];
   
    
   // if( *Pos_connec > 58700 ){
   // printf( "Print %d", *Pos_connec);
   // printf("\n");}
    
    if( bond_out[0][*snode] > 0  ){
    for (k=1; k<=bond_out[0][*snode] ; k++ ){
       if(connec_bool[*snode] == 0) {
       if(bond_out[*snode][k] != 0) {
      
       if(connec_bool[bond_out[*snode][k]] == 0) { //New
             if( *Pos_connec > 58700 ){
         
             }
           *Pos_connec +=1;
       connec_nodes[*Pos_connec] = bond_out[*snode][k];
       }
       //connec_nodes[k+KK-1] = bond_out[node][k];
           //KK++;
       }}
       //dist_out[bond_out[node][k]] =1;
       //dist_out[node] = 1;
       // dist_out[bond_out[0][k]] =1;
       // }
        if (k== bond_out[0][*snode]){
        // if (k==KK+bond_out[0][node]-1){
         connec_bool[*snode]=1;
         }
         }}
 
    //KK = *Pos_connec;
   // addK = addK+1;
   // K = &addK;
    *K = *K + 1;
    
    //nodeInd = *K;
   
       //if (*K < 200){
       if (*K < N+1){
       //if (K[node] < N+1){
           
        if (connec_nodes[*K] != 0 ){
       // if(connec_nodes[*K] <= N){
            
        //if(connec_nodes[*K] <= N && (*Pos_connec < stop || KK > 1 ) ) {
        //printf( "BFDP, %d, %d",*Pos_connec, KK );
        //printf("\n");
        if( connec_nodes[*K] <= N && (*Pos_connec < KK) ){
            
        //printf( "BFDPIN, %d, %d",*Pos_connec, KK );
        //printf("\n");
        //if(connec_nodes[*K] <= N && (*Pos_connec <=50000 || KK > 1 ) ) {
        //if(connec_nodes[*K] <= N && (*Pos_connec <=100000 || KK > 2 ) ) {
        //if(connec_nodes[*K] <= N && (*Pos_connec <=140000 || KK > 3 ) ) {
               
        // if(connec_nodes[*K] <= N ){
        // if( *Pos_connec > 58000 ){
       // printf( "BFDP, %d, %d, %d", *K, *snode , *Pos_connec);
        //printf( "BFDP, %d, %d", KK, *Pos_connec);
        //printf("\n");
         //printf( ", %d", *snode);
        // }
        //if( bond_out[0][connec_nodes[*K]] !=0    ){
    avalanche( K, N, T, snode, bond_in, bond_out, connec_nodes, nodes_degrees, KK, dist_out, dist_in, connec_bool, Pos_connec);
            
     //BEFORE  if (connec_nodes[K] != 0) 12 FEB
     //avalanche( K, N, T, connec_nodes[*K], bond_in, bond_out, connec_nodes, nodes_degrees, KK, dist_out, dist_in, connec_bool, Pos_connec);//BEFORE  if (connec_nodes[K] != 0) 12 FEB
    } //}}
    }
       // avalanche( K, N, T, connec_nodes[k], bond_in, bond_out, connec_nodes, nodes_degrees, KK, dist_out, dist_in);
     // K +=1;
    //connec_nodes = (int *) realloc(connec_nodes, (56) * sizeof(int));
    //connec_nodes = (int *) realloc(connec_nodes, 56);
     } }
    

//connec_nodes: array to store the avanlache nodes from a seed node
//connec_nodes_nDoubles: array to store the avanlache nodes from a seed node with no duplicates
//L:The lenght of connec_nodes array, i.e. avalanche nodes with duplicates
//nAval:The lenght of connec_nodes_nDoubles array, i.e. avalanche nodes without duplicates

void connec_nodes_no_duplicates(int *connec_nodes, int *connec_nodes_nDoubles, int* length,  int *avalance_nodes, int node)
{

   //  printf(" nDoubles  %d", length);
      //  printf("\n");
    int L =(int)length;
    //int L =90;
    
    //printf(" L nDoubles %d, %d" , length, L);
    //printf("\n");
       for (int i = 0; i < L; i++) {
    //printf(" nDoubles %d, %d, %d, %d, %d",i, connec_nodes_nDoubles[i],  node,connec_nodes[i], L);
      //  printf("\n");
       }
    
     int temp = 0;

     for (int i = 0; i < L; i++) {
           
        
         
       for (int j = i+1; j < L; j++) {
         if(connec_nodes[i] > connec_nodes[j]) {
         temp = connec_nodes[i];
         connec_nodes[i] = connec_nodes[j];
         connec_nodes[j] = temp;
         }
       }
     }
     
   // for (int i = 0; i < L; i++) {
      //printf(" connec_nodes %d,, %d,, %d",i, connec_nodes[i], L);
       // printf("\n");
    //}
    
       connec_nodes_nDoubles[1] = connec_nodes[1];
    
       int nAval = 1;//Avalache connec_nodes array lenght without duplicated nodes
           for (int i = 1; i < L+1; i++) {
               
               
           if ( connec_nodes[i+1] != connec_nodes[i] && connec_nodes[i]!=node ){
            //if(    connec_nodes[i] <=N ;)
                connec_nodes_nDoubles[nAval] = connec_nodes[i];
                nAval++;
               
               
              }
           else{ //printf(" Double HERE   %d, , %d",i, connec_nodes[i]);
           //printf("\n");
           }
           }
    
    
     avalance_nodes[node] = nAval-1;
     //avalance_nodes[node] = nAval;
    
    
    // for (int i = 0; i < nAval; i++) {
     // printf(" L %d, , %d", L, nAval-1);
    // printf("\n");
    // }
       
       
    for (int i = 0; i < nAval; i++) {
     //printf(" nDoubles %d, , %d, ,%d, %d",i, connec_nodes_nDoubles[i], nAval, node);
        // printf("\n");
    //printf(" nD %d, , %d, ,%d, %d",i, connec_nodes[i], nAval, node);
    //printf("\n");
    //printf(" Aval nDoubles ,%d, %d", avalance_nodes[node], node);
    //printf("\n");
    }
    
    
    for(int i=1;i<=L+1;i++)
    {
        connec_nodes[i] = 0;
    }
       }





void multiple_simulations_Avalanches( int K, int N,int T, int node, int **bond_in, int **bond_out, int *connec_nodes, int *nodes_degrees, int KK,  int *dist_out,  int *dist_in ){
    
    //for(int i=1; i<6 ; i++){
    for(int i=1; i<6 ; i++){
     
        //avalanche (K, N, T, i, bond_in, bond_out, connec_nodes, nodes_degrees, KK, dist_out, dist_in);
        
    }
}


int* connected_nodes_length( int *connec_nodes, int ind, int *length) {
       //int ind = 1;
    
    
           //while( connec_nodes[ind] !=0) {
           while( connec_nodes[ind] !=0) {
           //do{
            //printf( "Connected nodes size, %d, %d", connec_nodes[ind], ind);
            //printf("\n");
                ind++;
                length++;
            //printf( "Connected nodes size %d", ind);
            //printf("\n");
                //lenght++;
            }
            //}while( connec_nodes[ind] !=0);
    
    //printf( "Lenght in , %d", ind );
            //   printf("\n");
    
    return length;
   // return &ind;
    
}
