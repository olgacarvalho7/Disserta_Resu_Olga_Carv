//
//  link_dynamics.h
//  avalanche_code
//
//  Created by Olga Carvalho on 07/01/2022.
//  Copyright © 2022 Olga Carvalho. All rights reserved.
//

#ifndef link_dynamics_h
#define link_dynamics_h

#include <stdio.h>
void initial_reset_network_directed_LINK_DYNAMICS (int N, int *state_nodes, int M, int *state_links, int *infected_links, int *pos_infected_links, int *frontier_links, int *pos_frontier_links);
void init_state_network_directed_LINK_DYNAMICS (int N, int **bond_in, int **bond_out, int node, int *state_nodes, int M, int *state_links, int *infected_links, int *pos_infected_links, int *frontier_links, int *pos_frontier_links, int **links, int **bond_in_to_links, int **bond_out_to_links);
void multiple_simulations_directed_LINK_DYNAMICS (int N, int **bond_in, int **bond_out, double MAX_Lifetime, int T, double **results);
void single_step_directed_LINK_DYNAMICS (int N, int **bond_in, int **bond_out, int *state_nodes, int M, int *state_links, int *infected_links, int *pos_infected_links, int *frontier_links, int *pos_frontier_links, int **links, int **bond_in_to_links, int **bond_out_to_links, double *results);
#endif /* link_dynamics_h */
