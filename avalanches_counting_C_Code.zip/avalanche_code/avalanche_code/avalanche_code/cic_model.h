//
//  cic_model.h
//  avalanche_code
//
//  Created by Olga Carvalho on 08/01/2022.
//  Copyright © 2022 Olga Carvalho. All rights reserved.
//

#ifndef cic_model_h
#define cic_model_h

#include <stdio.h>
void single_step_directed_CIC (int N, int **bond_in, int **bond_out, double mu, int *state, int *infected, int *pos_infected, int *frontier_in, int *pos_frontier_in, int *frontier_out, int *pos_frontier_out, int *tmp_vector, double *results);
//void init_network_directed_CIC (int N, int **bond_in, int **bond_out, int node, int *state, int *infected, int *pos_infected, int *frontier_in, int *pos_frontier_in, int *frontier_out, int *pos_frontier_out);

void initial_reset_network_directed_CIC (int N, int *state, int *infected, int *pos_infected, int *frontier_in, int *pos_frontier_in, int *frontier_out, int *pos_frontier_out);

void init_state_network_directed_CIC (int N, int **bond_in, int **bond_out, int node, int *state, int *infected, int *pos_infected, int *frontier_in, int *pos_frontier_in, int *frontier_out, int *pos_frontier_out);

void multiple_simulations_directed_CIC (int N, int **bond_in, int **bond_out, double mu, double MAX_Lifetime, int T, double **results);

#endif /* cic_model_h */
