//
//  BFDP.h
//  avalanche_code
//
//  Created by Olga Carvalho on 26/01/2022.
//  Copyright © 2022 Olga Carvalho. All rights reserved.
//

#ifndef BFDP_h
#define BFDP_h

#include <stdio.h>

//void all_connected_nodes ( int K, int N,int T, int i, int **bond_in, int **bond_out, int *connec_nodes, int *nodes_degrees, int KK,  int *dist_out,  int *dist_in);


//void all_connected_nodes ( int K, int N,int T, int node, int **bond_in, int **bond_out, int *connec_nodes, int *nodes_degrees, int KK,  int *dist_out,  int *dist_in);


void avalanche (int *K, int N,int T, int *snode, int **bond_in, int **bond_out, int *connec_nodes, int *nodes_degrees, int KK,  int *dist_out,  int *dist_in, int *connec_bool,int *Pos_connec);

void connec_nodes_no_duplicates(int *connec_nodes, int *connec_nodes_nDoubles, int* length,  int *avalance_nodes, int node);

void multiple_simulations_Avalanches( int K, int N,int T, int node, int **bond_in, int **bond_out, int *connec_nodes, int *nodes_degrees, int KK,  int *dist_out,  int *dist_in );
//void connected_nodes_lenght( int *connec_nodes, int ind,  int *length);

int* connected_nodes_length( int *connec_nodes, int ind,  int *length);
#endif /* BFDP_h */
