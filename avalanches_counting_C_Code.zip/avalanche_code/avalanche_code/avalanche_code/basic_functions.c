//
//  basic_functions.c
//  avalanche_code
//
//  Created by Olga Carvalho on 07/01/2022.
//  Copyright © 2022 Olga Carvalho. All rights reserved.
//
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>
#include <time.h>
#include "mt64.h"
#include "basic_functions.h"


//////////////////////////////////////
//Counts the total number of nodes in the network
int count_nodes (char *filename)
{
  FILE *f;
  int i, j, q;
  int N = 0;

  f = fopen(filename,"r");
  while(!feof(f))
    {
      q = fscanf(f,"%d %d",&i,&j);
      if (q<=0) goto exit_file;
      if(i>N) N = i;
      if(j>N) N = j;
    }
 exit_file:
  fclose(f);
  return N;
}




//Reads edge list
void read_edges_directed (char *filename, int N, int **bond_in, int **bond_out)
{
  FILE *f;
    int i, j, q;// k, h;
    i = 0;
    j = 0;
    q = 0;
  
   //for(h=1;h<=N;h++){
       //for(i=1;i<=N;i++){ bond_in[h][i] = bond_out[h][i] = 0;
   //}}
    
   for(i=1;i<=N;i++) bond_in[i][0] = bond_out[i][0] = 0;

  f = fopen(filename,"r");
  while(!feof(f))
    {
      q = fscanf(f,"%d %d",&i,&j);
      if (q<=0) goto exit_file_A;


      bond_out[0][i]++;
      bond_in[0][j]++;

    }
 exit_file_A:
  fclose(f);


    
   for(i=1;i<=N;i++)
    {

      bond_in[i] = (int *)realloc(bond_in[i], (bond_in[0][i]+1)*sizeof(int));
      bond_in[0][i] = 0;

      bond_out[i] = (int *)realloc(bond_out[i], (bond_out[0][i]+1)*sizeof(int));
      bond_out[0][i] = 0;
    

     }

    
  
    
  f = fopen(filename,"r");
  while(!feof(f))
    {
      q = fscanf(f,"%d %d",&i,&j);
      if (q<=0) goto exit_file;

      if(i!=j)
    {
        
      // IMPORTANT: note the bond_out array corresponding to the edges are the following 0->1(1), ... 0->N(NEdges),(i.e ID of output node, 1st column from input file)
      // 1->1(NEdges+1),1->2(NEdges+2)...1->OutDegree(NEdges+1OutDegree),  ... ,NEdges->NMinusEdgesOutDegree(N-NEdgesOutDegree),...,N->N(N)
        
      if(find_neighbor(i, j, bond_out)<0){ //remove this check if (1) your input network doesn't contain multiple edges or (2) it does contain multiple edges and you want to include them in the simulations
        bond_out[0][i]++;
        bond_out[i][bond_out[0][i]] = j;
        //printf("%d, ,%d", i, bond_out[0][i]);
        //printf("\n");
       // printf("%d, ,%d, ,%d", i, bond_out[0][i], bond_out[i][bond_out[0][i]]);
        //printf("\n");
      }
   
        
      if(find_neighbor(j, i, bond_in)<0){ //remove this check if (1) your input network doesn't contain multiple edges or (2) it does contain multiple edges and you want to include them in the simulations
        bond_in[0][j]++;
        bond_in[j][bond_in[0][j]] = i;
        //printf("# Model : betal = %g\n", bond_in[j][bond_in[0][j]] );
        //printf("%d ", bond_in[j][bond_in[0][j]]);
        //printf("\n");
      }
        
        
       

     
    }
        
    }
    
   
    
 exit_file:
  fclose(f);
    
    //for(k=1;k<=N;k++){
            //printf("# Model : beta = %g\n", bond_in[0][k]);
            //printf("# Model : beta = %g\n", bond_out[0][k]);
         //}
}



void make_network_symmetric (int N, int **bond_in, int **bond_out)
{
  int i, j, n;

  for(i=1;i<=N;i++)
    {
      for(j=1;j<=bond_in[0][i];j++)
    {
      n = bond_in[i][j];
      if(find_neighbor(n, i, bond_in)<0){
        bond_in[0][n]++;
        bond_in[n] = (int *)realloc(bond_in[n], (bond_in[0][n]+1) * sizeof(int));
        bond_in[n][bond_in[0][n]] = i;
      }
    }
    }

  
  for(i=1;i<=N;i++)
    {
      for(j=1;j<=bond_out[0][i];j++)
    {
      n = bond_out[i][j];
       if(find_neighbor(n, i, bond_out)<0){
         bond_out[0][n]++;
         bond_out[n] = (int *)realloc(bond_out[n], (bond_out[0][n]+1) * sizeof(int));
         bond_out[n][bond_out[0][n]] = i;
       }
    }
    }
}


////////////

int random_selection_from_set (int *set)
{
  int s;
  s = (int)(genrand64_real3() * (double)set[0]) + 1;
  if (s > set[0]) s = 1;
  return set[s];
}

void add_to_set (int *set, int *positions, int element)
{
  set[0]++;
  set[set[0]] = element;
  positions[element] = set[0];
}


void remove_from_set (int *set, int *positions, int element)
{
  int pos  = positions[element];
  int last = set[set[0]];
  set[pos] = last;
  positions[last] = pos;
  set[0]--;
  positions[element] = -1;
}







int find_neighbor(int i, int j, int **bond)
{
  int k;
  for(k=1;k<=bond[0][i];k++) if (bond[i][k] == j) return k;
  return -1;
}







///////////////





double single_iteration (int N, int **bond, double *vec, double *vec_old)
{

  int i, j, n;

  for(i=1;i<=N;i++)
    {
      vec_old[i]=vec[i];
      vec[i]=0.0;
    }


  for(i=1;i<=N;i++)
    {
      for(j=1;j<=bond[0][i];j++)
        {
          n=bond[i][j];
          vec[n]+=vec_old[i];
        }
    }


  double l2=normalize_vector (N, vec);

  return l2;
}


double largest_eigenvalue (int N, int **bond)
{
  
  
  double  err, l2;
  l2=0;
  double *vec, *vec_old;
  vec=(double *)malloc((N+1)*sizeof(double));
  vec_old=(double *)malloc((N+1)*sizeof(double));


  init_vector (N, vec);

  double SENS = 1.0 / (double)N;
  if(SENS > 1.0e-6) SENS = 1.0e-6;

  int iter=0;
  err=1.0e10;
  while(err>SENS)
    {
      iter++;
      l2=single_iteration (N, bond, vec, vec_old);
      err=estimate_error (N, vec, vec_old);
                                                                                                                                              
    }

  free(vec_old);
  free(vec);


  return l2;
}



double normalize_vector (int N, double *vec)
{
  int i;
  double norm=0.0;
  for(i=1;i<=N;i++) norm+=vec[i]*vec[i];
  norm=sqrt(norm);
  for(i=1;i<=N;i++) vec[i]/=norm;
  return norm;
}

double estimate_error (int N, double *vec1, double *vec2)
{
  double err=0.0;
  int i;
  for(i=1;i<=N;i++) err+=fabs(fabs(vec1[i])-fabs(vec2[i]));
  return err;
}


void init_vector (int N, double *vec)
{
  int i;
  double q;
  for(i=1;i<=N;i++) vec[i]=-1.0+2.0*genrand64_real3();
  q = normalize_vector (N, vec);
}









////////////////






double largest_nonbacktracking (int N, int **bond)
{

  
  double l2, err;
  l2=0;

  double *vec = (double *)malloc((2*N+1)*sizeof(double));
  double *vec_tmp = (double *)malloc((2*N+1)*sizeof(double));
  

  
  init_vector (2*N, vec);


  double SENS = 1.0 / (double)N;
  if(SENS > 1.0e-6) SENS = 1.0e-6;


 
  int iter=0;
  err=1.0e10;
  while(err>SENS)
  {
    iter++;
    l2 = single_iteration_nonback (N, bond, vec, vec_tmp);
    err = estimate_error (2*N, vec, vec_tmp);
    if(iter>10000)
      {
    printf("#A) Algorithm did not converge!!\n");
    l2 = -100.0;
    goto exitloop;
      }
   }


 exitloop:
 

  free(vec);
  free(vec_tmp);
  



  return l2;

}





double single_iteration_nonback(int N, int **bond, double *vec, double *vec_tmp)
{
  double tmp;
  int i, j, n;

  

  for(i=1;i<=2*N;i++)
    {
      vec_tmp[i] = vec[i];
      vec[i] = 0.0;
    }


  for(i=1;i<=N;i++)
    {
      for(j=1;j<=bond[0][i];j++)
    {
      n = bond[i][j];
      tmp = 1.0;
      if(n!=i) vec[n] += tmp*vec_tmp[i];
      if(n==i) vec[n] += 2.0*tmp*vec_tmp[i];
    }
    }

  for(i=1;i<=N;i++)
    {
      vec[i] += vec_tmp[i+N] * (1.0 - (double)bond[0][i]);
    }
 
  for(i=N+1;i<=2*N;i++) vec[i] = vec_tmp[i - N];
  



  double l2=normalize_vector (2*N, vec);
 
  return l2;
}



