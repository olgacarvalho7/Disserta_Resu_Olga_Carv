//
//  cic_model.c
//  avalanche_code
//
//  Created by Olga Carvalho on 08/01/2022.
//  Copyright © 2022 Olga Carvalho. All rights reserved.
//

#include "cic_model.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>
#include <time.h>
#include "mt64.h"
#include "basic_functions.h"

//////////
//the set frontier_out is not used in the simulation and may be removed completely to make the code
//cleaner
/////////





void single_step_directed_CIC (int N, int **bond_in, int **bond_out, double mu, int *state, int *infected, int *pos_infected, int *frontier_in, int *pos_frontier_in, int *frontier_out, int *pos_frontier_out, int *tmp_vector, double *results)
{

  double norm, rate1a, rate1b, rate2;
  rate1a = (1.0-mu) * (double)infected[0];
  rate1b = mu * (double)infected[0];
  rate2 = (double)frontier_in[0];
  norm = rate1a + rate1b + rate2;


  double p = genrand64_real3();
 
  int i, v, node, j, n, m, control;

  ///////////////////////////
  if (p <= rate1a / norm)
    {

      


      //reaction 1
      results[0] += 1.0; //popularity increase
      node =  random_selection_from_set (infected);
     
      //printf("reaction 1 : %d\n",node);
      

      tmp_vector[0] = 0;

    //LOOKS AT ALL OUTEDGES OF THE SEED NODE
      for(j=1;j<=bond_out[0][node];j++)
    {
      n = bond_out[node][j];


      //printf("->%d(%d)\n",n,state[n]);

      if (state[n] == 2)
        {
          state[n] = 1;
          add_to_set (infected, pos_infected, n);
          remove_from_set (frontier_out, pos_frontier_out, n);
          tmp_vector[0]++;
          tmp_vector[tmp_vector[0]] = n;
        }

      if (state[n] == 4)
        {
          state[n] = 1;
          add_to_set (infected, pos_infected, n);
          remove_from_set (frontier_out, pos_frontier_out, n);
          remove_from_set (frontier_in, pos_frontier_in, n);
          tmp_vector[0]++;
          tmp_vector[tmp_vector[0]] = n;
        }


      /*
      if(state[n] == 3 || state[n] == 0)
        {
          printf("Error\n");
        }
      */

    }

      //printf("----> %d\n",tmp_vector[0]);



      for(i=1;i<=tmp_vector[0];i++){

    n = tmp_vector[i];
    //printf("out %d\n",n);

    for(j=1;j<=bond_out[0][n];j++)
      {
        m = bond_out[n][j];
        //printf("%d %d",m, state[m]);

        if (state[m] == 0)
          {
        state[m] = 2;
        add_to_set (frontier_out, pos_frontier_out, m);
          }

        if (state[m] == 3)
          {
        state[m] = 4;
        add_to_set (frontier_out, pos_frontier_out, m);
          }

        //printf("->%d\n",state[m]);

      }
      }




      for(i=1;i<=tmp_vector[0];i++){

    n = tmp_vector[i];


    for(j=1;j<=bond_in[0][n];j++)
          {
            m = bond_in[n][j];


            if (state[m] == 0)
              {
                state[m] = 3;
                add_to_set (frontier_in, pos_frontier_in, m);
              }

            if (state[m] == 2)
              {
                state[m] = 4;
                add_to_set (frontier_in, pos_frontier_in, m);
              }


          }
      }

      
    }



  //////////////////////////////////
  if (p > rate1a / norm && p <= (rate1a+rate1b) / norm)
    {




      node =  random_selection_from_set (infected);



      state[node] = 0;
      remove_from_set (infected, pos_infected, node);

      tmp_vector[0] = 1;
      tmp_vector[tmp_vector[0]] = node;
      

      for(j=1;j<=bond_out[0][node];j++)
        {
          n = bond_out[node][j];

          if (state[n] == 1)
            {
              state[n] = 0;
              remove_from_set (infected, pos_infected, n);
              tmp_vector[0]++;
              tmp_vector[tmp_vector[0]] = n;

          for(v=1;v<=bond_out[0][n];v++)
        {

          m = bond_out[n][v];
          if(state[m] == 2)
            {
              state[m] = 0;
              remove_from_set (frontier_out, pos_frontier_out, m);
              tmp_vector[0]++;
              tmp_vector[tmp_vector[0]] = m;
            }

          if(state[m] == 4)
            {
              state[m] = 0;
              remove_from_set (frontier_out, pos_frontier_out, m);
              remove_from_set (frontier_in, pos_frontier_in, m);
              tmp_vector[0]++;
              tmp_vector[tmp_vector[0]] = m;
            }
        }


          for(v=1;v<=bond_in[0][n];v++)
        {

          m = bond_in[n][v];
          if(state[m] == 3)
            {
              state[m] = 0;
              remove_from_set (frontier_in, pos_frontier_in, m);
              tmp_vector[0]++;
              tmp_vector[tmp_vector[0]] = m;
            }
        
          if(state[m] == 4)
            {
              state[m] = 0;
              remove_from_set (frontier_out, pos_frontier_out, m);
              remove_from_set (frontier_in, pos_frontier_in, m);
              tmp_vector[0]++;
              tmp_vector[tmp_vector[0]] = m;
            }
        }

            }


            

      if (state[n] == 2)
            {
              state[n] = 0;
              remove_from_set (frontier_out, pos_frontier_out, n);
          tmp_vector[0]++;
              tmp_vector[tmp_vector[0]] = n;
        }

      if (state[n] == 4)
            {
              state[n] = 0;
              remove_from_set (frontier_out, pos_frontier_out, n);
              remove_from_set (frontier_in, pos_frontier_in, n);
          tmp_vector[0]++;
              tmp_vector[tmp_vector[0]] = n;
        }
        }



      for(j=1;j<=bond_in[0][node];j++)
        {
          n = bond_in[node][j];

      if (state[n] == 3)
            {
              state[n] = 0;
              remove_from_set (frontier_in, pos_frontier_in, n);
              tmp_vector[0]++;
              tmp_vector[tmp_vector[0]] = n;
            }

          if (state[n] == 4)
            {
              state[n] = 0;
              remove_from_set (frontier_out, pos_frontier_out, n);
              remove_from_set (frontier_in, pos_frontier_in, n);
              tmp_vector[0]++;
              tmp_vector[tmp_vector[0]] = n;
            }
    }


    


      for(i=1;i<=tmp_vector[0];i++){
    
    n = tmp_vector[i];
    control = 0;
        
    for(j=1;j<=bond_out[0][n];j++)
          {
            m = bond_out[n][j];
            if (state[m] == 1) control ++;
      }
    
    if (control > 0){
      state[n] = 3;
      add_to_set (frontier_in, pos_frontier_in, n);
    }


    control = 0;
        for(j=1;j<=bond_in[0][n];j++)
          {
            m = bond_in[n][j];
            if (state[m] == 1) control ++;
          }


    if (control > 0){
      if (state[n] == 0)
        {
          state[n] = 2;
          add_to_set (frontier_out, pos_frontier_out, n);
        }
      if (state[n] == 3)
        {
          state[n] = 4;
          add_to_set (frontier_out, pos_frontier_out, n);
        }
        }


      }
    

    }
  ////////////////////////////

  int tmp = 0;

  if (p > (rate1a+rate1b) / norm)
    {



      node =  random_selection_from_set (frontier_in);




      if (state[node] == 3)
    {
      state[node] = 0;
      remove_from_set (frontier_in, pos_frontier_in, node);
    }
      if (state[node] == 4)
    {
      state[node] = 0;
      remove_from_set (frontier_out, pos_frontier_out, node);
      remove_from_set (frontier_in, pos_frontier_in, node);
    }


      tmp_vector[0] = 1;
      tmp_vector[tmp_vector[0]] = node;
      



      for(j=1;j<=bond_out[0][node];j++)
        {
          n = bond_out[node][j];
          
      
      if (state[n] == 1)
            {

          tmp ++;
         
          state[n] = 0;
              remove_from_set (infected, pos_infected, n);
              tmp_vector[0]++;
              tmp_vector[tmp_vector[0]] = n;


          for(v=1;v<=bond_out[0][n];v++)
        {
          m = bond_out[n][v];
          if(state[m] == 2)
            {
              state[m] = 0;
              remove_from_set (frontier_out, pos_frontier_out, m);
              tmp_vector[0]++;
              tmp_vector[tmp_vector[0]] = m;
            }

          if(state[m] == 4)
            {
              state[m] = 0;
              remove_from_set (frontier_out, pos_frontier_out, m);
              remove_from_set (frontier_in, pos_frontier_in, m);
              tmp_vector[0]++;
              tmp_vector[tmp_vector[0]] = m;
            }
        }
            



          for(v=1;v<=bond_in[0][n];v++)
        {
          m = bond_in[n][v];
          if(state[m] == 3)
            {
              state[m] = 0;
              remove_from_set (frontier_in, pos_frontier_in, m);
              tmp_vector[0]++;
              tmp_vector[tmp_vector[0]] = m;
            }

          if(state[m] == 4)
            {
              state[m] = 0;
              remove_from_set (frontier_out, pos_frontier_out, m);
              remove_from_set (frontier_in, pos_frontier_in, m);
              tmp_vector[0]++;
              tmp_vector[tmp_vector[0]] = m;
            }
        }



            }

     
        }

      /*
      if(tmp < 1)
    {
      printf("Mistake!\n");
      exit(0);
    }
      */


      for(i=1;i<=tmp_vector[0];i++){
        n = tmp_vector[i];
    control = 0;
        

    

    for(j=1;j<=bond_out[0][n];j++)
          {
            m = bond_out[n][j];
    
            if (state[m] == 1) control ++;
      }
    
    if (control > 0){
      state[n] = 3;
      add_to_set (frontier_in, pos_frontier_in, n);
    }



    control = 0;
        for(j=1;j<=bond_in[0][n];j++)
          {
            m = bond_in[n][j];

            if (state[m] == 1) control ++;
          }


    if (control > 0){
      if (state[n] == 0)
        {
          state[n] = 2;
          add_to_set (frontier_out, pos_frontier_out, n);
        }
      if (state[n] == 3)
        {
          state[n] = 4;
          add_to_set (frontier_out, pos_frontier_out, n);
        }
      
        }



      }

      

    }


  results[1] -= log(genrand64_real3()) / norm;
  results[2] += (double)(ceil(log(1.0-genrand64_real3()) / log(1.0-norm/(double)N))) / (double)N;


}








void initial_reset_network_directed_CIC (int N, int *state, int *infected, int *pos_infected, int *frontier_in, int *pos_frontier_in, int *frontier_out, int *pos_frontier_out)
{

  int j;

 /////////
  for(j=1;j<=N;j++)
    {
      state[j] = 0;
      infected[j] = -1;
      pos_infected[j] = -1;
      frontier_in[j] = -1;
      pos_frontier_in[j] = -1;
      frontier_out[j] = -1;
      pos_frontier_out[j] = -1;
    }
  infected[0] = 0;
  frontier_in[0] = 0;
  frontier_out[0] = 0;
  ///////
}



void init_state_network_directed_CIC (int N, int **bond_in, int **bond_out, int node, int *state, int *infected, int *pos_infected, int *frontier_in, int *pos_frontier_in, int *frontier_out, int *pos_frontier_out)
{

  int i, j, n, m;
  
  while(infected[0]>0)
    {
      n = infected[1];
      remove_from_set (infected, pos_infected, n);
      state[n] = 0;
    }

  while(frontier_in[0]>0)
    {
      n = frontier_in[1];
      remove_from_set (frontier_in, pos_frontier_in, n);
      state[n] = 0;
    }


  while(frontier_out[0]>0)
    {
      n = frontier_out[1];
      remove_from_set (frontier_out, pos_frontier_out, n);
      state[n] = 0;
    }


//
  add_to_set (infected, pos_infected, node);
  state[node] = 1;
  
  for(j=1;j<=bond_out[0][node];j++)
    {
      n = bond_out[node][j];
      add_to_set (infected, pos_infected, n);
      state[n] = 1;
    }
  ///////


  for(i=1;i<=infected[0];i++)
    {
      n = infected[i];
      for(j=1;j<=bond_out[0][n];j++)
    {
      m = bond_out[n][j];
      if (state[m] == 0)
        {
          state[m] = 2;
          add_to_set (frontier_out, pos_frontier_out, m);
        }
    }
    }


  for(i=1;i<=infected[0];i++)
    {
      n = infected[i];
      for(j=1;j<=bond_in[0][n];j++)
    {
      m = bond_in[n][j];
      if (state[m] == 0)
        {
          state[m] = 3;
          add_to_set (frontier_in, pos_frontier_in, m);
        }

      if (state[m] == 2)
        {
          state[m] = 4;
          add_to_set (frontier_in, pos_frontier_in, m);
        }
    }
    }

}



//The one below is an old and slower version of the function that resets the state of the system. It may be safely deleted from the code.
/*
void init_network_directed_CIC (int N, int **bond_in, int **bond_out, int node, int *state, int *infected, int *pos_infected, int *frontier_in, int *pos_frontier_in, int *frontier_out, int *pos_frontier_out)
{

  int i, j, n, m;

  /////////
  for(j=1;j<=N;j++)
    {
      state[j] = 0;
      infected[j] = -1;
      pos_infected[j] = -1;
      frontier_in[j] = -1;
      pos_frontier_in[j] = -1;
      frontier_out[j] = -1;
      pos_frontier_out[j] = -1;
    }
  infected[0] = 0;
  frontier_in[0] = 0;
  frontier_out[0] = 0;
  ///////
  
  

  
  //
  add_to_set (infected, pos_infected, node);
  state[node] = 1;
  
  for(j=1;j<=bond_out[0][node];j++)
    {
      n = bond_out[node][j];
      add_to_set (infected, pos_infected, n);
      state[n] = 1;
    }
  ///////


  for(i=1;i<=infected[0];i++)
    {
      n = infected[i];
      for(j=1;j<=bond_out[0][n];j++)
    {
      m = bond_out[n][j];
      if (state[m] == 0)
        {
          state[m] = 2;
          add_to_set (frontier_out, pos_frontier_out, m);
        }
    }
    }




  for(i=1;i<=infected[0];i++)
    {
      n = infected[i];
      for(j=1;j<=bond_in[0][n];j++)
    {
      m = bond_in[n][j];
      if (state[m] == 0)
        {
          state[m] = 3;
          add_to_set (frontier_in, pos_frontier_in, m);
        }

      if (state[m] == 2)
        {
          state[m] = 4;
          add_to_set (frontier_in, pos_frontier_in, m);
        }
    }
    }



}
*/

void multiple_simulations_directed_CIC (int N, int **bond_in, int **bond_out, double mu, double MAX_Lifetime, int T, double **results)
{

  int t;

  //memory allocation
  int *state = (int *)malloc((N+1)*sizeof(int));
  int *infected = (int *)malloc((N+1)*sizeof(int));
  int *pos_infected = (int *)malloc((N+1)*sizeof(int));
  int *frontier_in = (int *)malloc((N+1)*sizeof(int));
  int *pos_frontier_in = (int *)malloc((N+1)*sizeof(int));
  int *frontier_out = (int *)malloc((N+1)*sizeof(int));
  int *pos_frontier_out = (int *)malloc((N+1)*sizeof(int));
  int *tmp_vector = (int *)malloc((N+1)*sizeof(int));
  //

  initial_reset_network_directed_CIC (N, state, infected, pos_infected, frontier_in, pos_frontier_in, frontier_out, pos_frontier_out);

  int r_node;
  int control;
  int kk = 0;

  for(t=1;t<=T;t++)
    {


      if(t>kk)
        {
          printf("%d of %d\n",t,T); fflush(stdout);
          kk += (int)(0.05*(double)T);
        }


    again:
      //r_node = (int)(genrand64_real3()*(double)N)+1;
      r_node = (int)(genrand64_real3()*(double)4)+1;
      if(r_node > N) r_node = 1;
     
        
      //printf("%d, %d\n",r_node, bond_in[0][r_node]);
      if(bond_in[0][r_node]==0)  goto again;

        
      //init_network_directed_CIC (N, bond_in, bond_out, r_node, state, infected, pos_infected, frontier_in, pos_frontier_in, frontier_out, pos_frontier_out);

      init_state_network_directed_CIC (N, bond_in, bond_out, r_node, state, infected, pos_infected, frontier_in, pos_frontier_in, frontier_out, pos_frontier_out);
  




      results[t][0] = 1.0;
      results[t][1] = 0.0;
      results[t][2] = 0.0;
      results[t][3] = r_node;
      
      control = -1;

      while(control < 0 && results[t][1] < MAX_Lifetime && infected[0] > 0)
    {


      single_step_directed_CIC (N, bond_in, bond_out, mu, state, infected, pos_infected, frontier_in, pos_frontier_in, frontier_out, pos_frontier_out, tmp_vector, results[t]);



      if(mu == 0.0 && infected[0] == N)
        {
          control = 1;
          results[t][0] = - results[t][0];
        }

    }

    }

  //memory release
  free(state);
  free(infected);
  free(pos_infected);
  free(frontier_in);
  free(pos_frontier_in);
  free(frontier_out);
  free(pos_frontier_out);
  free(tmp_vector);
  //
}
