//
//  contact_process.c
//  avalanche_code
//
//  Created by Olga Carvalho on 07/01/2022.
//  Copyright © 2022 Olga Carvalho. All rights reserved.
//

#include "contact_process.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>
#include <time.h>
#include "mt64.h"
#include "basic_functions.h"




//////////


void initial_reset_network_directed_COP (int N, int *state, int *infected, int *pos_infected)
{

  int j;

  /////////
  for(j=1;j<=N;j++)
    {
      state[j] = 0;
      infected[j] = -1;
      pos_infected[j] = -1;
    }
  infected[0] = 0;
  ///////
  
}


void init_state_network_directed_COP (int N, int **bond_out, int node, int *state, int *infected, int *pos_infected)
{

  int n;
  
  while(infected[0]>0)
    {
      n = infected[1];
      remove_from_set (infected, pos_infected, n);
      state[n] = 0;
    }

  //printf("I = %d\n",infected[0]);
  
  add_to_set (infected, pos_infected, node);
  state[node] = 1;


  //printf("I = %d\n",infected[0]);
  

}

/////////



void multiple_simulations_directed_COP (int N, int **bond_in, int **bond_out, double lambda, double MAX_Lifetime, int T, double **results)
{

  int t;

  //memory allocation
  int *state = (int *)malloc((N+1)*sizeof(int));
  int *infected = (int *)malloc((N+1)*sizeof(int));
  int *pos_infected = (int *)malloc((N+1)*sizeof(int));
  //


 

  initial_reset_network_directed_COP (N, state, infected, pos_infected);
  

  int r_node, control;
  int kk = 0;

  for(t=1;t<=T;t++)
    {

    again:
      r_node = (int)(genrand64_real3()*(double)N)+1;
      if(r_node > N) r_node = 1;
      if(bond_in[0][r_node]==0) goto again;


       if(t>kk)
    {
      printf("%d of %d\n",t,T); fflush(stdout);
      kk += (int)(0.05*(double)T);
    }



      init_state_network_directed_COP (N, bond_out, r_node, state, infected, pos_infected);
      
  

      results[t][0] = 1.0;
      results[t][1] = 0.0;
      results[t][2] = 0.0;

      control = -1;

      while(control< 0 &&  infected[0] > 0 && results[t][1] < MAX_Lifetime)
    {
      single_step_directed_COP (N, bond_out, lambda, state, infected, pos_infected, results[t]);

     

      if(infected[0] == N)
        {
         
          control = 1;
          results[t][0] = -results[t][0];
        }

    }

    }

  //memory release
  free(state);
  free(infected);
  free(pos_infected);
  //

  
}






void single_step_directed_COP (int N, int **bond_out, double lambda, int *state, int *infected, int *pos_infected, double *results)
{

  double norm, rate1, rate2;
  rate1 = (double)lambda*(double)infected[0];
  rate2 = (double)infected[0];
  norm = rate1 + rate2;


  results[1] -= log(genrand64_real3()) / norm;
  results[2] += (double)(ceil(log(1.0-genrand64_real3()) / log(1.0-(double)infected[0]/(double)N))) / (double)N;


  double p = genrand64_real3();
 
  int v, node, n;

  ///////////////////////////
  if (p <= rate1 / norm)
    {
            
      node =  random_selection_from_set (infected);
     
      if(bond_out[0][node]>0){
    v = (int)(genrand64_real3()*(double)bond_out[0][node]) + 1;
    if (v>bond_out[0][node]) v = 1;
    n = bond_out[node][v];
    
    if(state[n] == 0)
      {
        add_to_set (infected, pos_infected, n);
        state[n] = 1;
        results[0] += 1;
      }

      }
    }


  ///////////////////////////
  if (p > rate1 / norm)
    {
      node =  random_selection_from_set (infected);
    
      remove_from_set (infected, pos_infected, node);
      state[node] = 0;
    }


}




