//
//  main.c
//  avalanche_code
//
//  Created by Olga Carvalho on 07/01/2022.
//  Copyright © 2022 Olga Carvalho. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>
#include <time.h>
#include <string.h>
#include "mt64.h"
#include "basic_functions.h"
#include "cic_model.h"
#include "invasion_process.h"
#include "voter_model.h"
#include "link_dynamics.h"
#include "sis_model.h"
#include "sir_model.h"
#include "contact_process.h"
#include "BFDP.h"


int main (int argc, char **argv)
{

  if(argc != 7 && strcmp(argv[1], "CN") != 0)
    {
      printf("\n\n#ERROR : You need to provide exactly four inputs and run the program as\n");
      printf("# ./avalanche_dynamics model param dir edge_list_file number_simulations result_file\n");

      printf("\n# \"model\" specifies the dynamical model used for avalanche dynamics\n");
      printf("# available options are:\n");
      printf("# CIC for Competition-Induced Criticality Model\n");
      printf("# VOT for Voter Model\n");
      printf("# INV for Invasion Process\n");
      printf("# LID for Link Dynamics\n");
      printf("# SIS for Susceptible-Infected-Susceptible Model\n");
      printf("# SIR for Susceptible-Infected-Recovered Model\n");
      printf("# COP for Contact Process\n");
      printf("# CN for Connected nodes Model\n");



      printf("\n# \"param\" specifies the value of the model parameter used in the simulations. The value of this parameter serves to change the dynamical regime, i.e., subcritical, critical or supercritical, of the model. The value of the parameter that put the system in the critical state generally depends on the dynamical process and the underlying network.\n");


      printf("\n# \"dir\" specifies if the network is directed or undirected. Set equal to 1 for directed, or any other value for undirected\n");


      printf("\n# \"edge_list_file\" specifies the name of the file containing the list of edges of the network\n");

      printf("\n# \"number_simulations\" is an integer number that indicates the total number of avalanches that you want to simulate\n");

      printf("\n# \"result_file\" specifies the name of the file where the program will output the results of the simulations\n\n\n");


      return(0);
    }
  //main variables
  int dynamical_model = 0;
  int directed = 1;

  double mu = 0.0; //used for CIC
  double beta = 1.0; //used for SIS, SIR, COP
  
  int KK = 0;
  int K = 0;
  int T = 0;
  int snode = 0;
  char network_file[150];
  char result_file[150];

 // FIX IT LATER CONTINUE HERE
 if (strcmp(argv[1], "CN") == 0)
    {
        
    dynamical_model = 1;
         printf("\n\n# Dynamics: Connected nodes Model CN \n");

         //K must be 0 always 1 in case we want all connected node
         K = atoi(argv[2]);
         printf("# Model parameter: K = %d\n", K);
        
        // seed node
         snode = atoi(argv[3]);
         printf("# The seed node: %d\n", snode);

         sprintf(network_file, "%s", argv[4]);
         printf("# Edge list: %s\n", network_file);
        
         T = atoi(argv[5]);
         printf("# Total number of simulations: %d\n", T);
        
         sprintf(result_file, "%s", argv[6]);
         printf("# Result file: %s\n", result_file);
        
         KK = atoi(argv[7]);
         printf("# Model parameter: K = %d\n", KK);
         //printf("# Critical regime is obtained by setting mu = 0.\n");
    }
    
    
  if (strcmp(argv[1], "CIC") == 0)
    {

      dynamical_model = 1;
      printf("\n\n# Dynamics: Competition-Induced Criticality Model\n");

      mu = atof(argv[2]);
      printf("# Model parameter: mu = %g\n", mu);

      directed = atoi(argv[3]);
      if(directed == 1) printf("# Network is directed\n");
      else printf("# Network is undirected\n");

      sprintf(network_file, "%s", argv[4]);
      printf("# Edge list: %s\n", network_file);

      T = atoi(argv[5]);
      printf("# Total number of simulations: %d\n", T);

      sprintf(result_file, "%s", argv[6]);
      printf("# Result file: %s\n", result_file);

      printf("# Critical regime is obtained by setting mu = 0.\n");

    }


  if (strcmp(argv[1], "VOT") == 0)
    {

      dynamical_model = 2;
      printf("\n\n# Dynamics: Voter Model\n");

      mu = atof(argv[2]);
      printf("# Model parameter: mu = %g\n", mu);

      directed = atoi(argv[3]);
      if(directed == 1) printf("# Network is directed\n");
      else printf("# Network is undirected\n");

      sprintf(network_file, "%s", argv[4]);
      printf("# Edge list: %s\n", network_file);

      T = atoi(argv[5]);
      printf("# Total number of simulations: %d\n", T);

      sprintf(result_file, "%s", argv[6]);
      printf("# Result file: %s\n", result_file);
        
      printf("# There is no parameter in the model!\n");
    }

  if (strcmp(argv[1], "INV") == 0)
    {

      dynamical_model = 3;
      printf("\n\n# Dynamics: Invasion Process\n");

      mu = atof(argv[2]);
      //printf("# Model parameter: mu = %g\n", mu);

      directed = atoi(argv[3]);
      if(directed == 1) printf("# Network is directed\n");
      else printf("# Network is undirected\n");

      sprintf(network_file, "%s", argv[4]);
      printf("# Edge list: %s\n", network_file);

      T = atoi(argv[5]);
      printf("# Total number of simulations: %d\n", T);

      sprintf(result_file, "%s", argv[6]);
      printf("# Result file: %s\n", result_file);

      printf("# There is no parameter in the model!\n");

    }



  if (strcmp(argv[1], "LID") == 0)
    {

      dynamical_model = 4;
      printf("\n\n# Dynamics: Link Dynamics\n");

       mu = atof(argv[2]);
      //printf("# Model parameter: mu = %g\n", mu);


       directed = atoi(argv[3]);
      if(directed == 1) printf("# Network is directed\n");
      else printf("# Network is undirected\n");

      sprintf(network_file, "%s", argv[4]);
      printf("# Edge list: %s\n", network_file);


      T = atoi(argv[5]);
      printf("# Total number of simulations: %d\n", T);

      sprintf(result_file, "%s", argv[6]);
      printf("# Result file: %s\n", result_file);

      printf("# There is no parameter in the model!\n");
    }

  if (strcmp(argv[1], "SIS") == 0)
    {
      dynamical_model = 5;
      printf("\n\n# Dynamics: SIS Model\n");

      beta = atof(argv[2]);
      printf("# Model parameter: Q = %g\n", beta);

      directed = atoi(argv[3]);
      if(directed == 1) printf("# Network is directed\n");
      else printf("# Network is undirected\n");

      sprintf(network_file, "%s", argv[4]);
      printf("# Edge list: %s\n", network_file);

      T = atoi(argv[5]);
      printf("# Total number of simulations: %d\n", T);

      sprintf(result_file, "%s", argv[6]);
      printf("# Result file: %s\n", result_file);

      printf("# The critical value of the epidemic rate beta_c of the model is approximated as the inverse of the largest eigenvalue of the adjacency matrix of the network. The actual epidemic rate used in the simulations is beta = Q * beta_c. You can change the value of the parameter Q to explore different dynamical regimes. \n");
    }
    
    if (strcmp(argv[1], "SIR") == 0)
    {

      dynamical_model = 6;
      printf("\n\n# Dynamics: SIR Model\n");

      beta = atof(argv[2]);
      printf("# Model parameter: Q = %g\n", beta);

      directed = atoi(argv[3]);
      if(directed == 1) printf("# Network is directed\n");
      else printf("# Network is undirected\n");

      sprintf(network_file, "%s", argv[4]);
      printf("# Edge list: %s\n", network_file);

      T = atoi(argv[5]);
      printf("# Total number of simulations: %d\n", T);

      sprintf(result_file, "%s", argv[6]);
      printf("# Result file: %s\n", result_file);

      printf("# The critical value of the epidemic rate beta_c of the model is approximated as the inverse of the largest eigenvalue of the non-backtracking matrix of the network. The actual epidemic rate used in the simulations is beta = Q * beta_c. You can change the value of the parameter beta to explore different dynamical regimes. \n");
    }

    if (strcmp(argv[1], "COP") == 0)
    {

      dynamical_model = 7;
      printf("\n\n# Dynamics: Contact Process\n");

       beta = atof(argv[2]);
      printf("# Model parameter: beta = %g\n", beta);

      directed = atoi(argv[3]);
      if(directed == 1) printf("# Network is directed\n");
      else printf("# Network is undirected\n");

      sprintf(network_file, "%s", argv[4]);
      printf("# Edge list: %s\n", network_file);

      T = atoi(argv[5]);
      printf("# Total number of simulations: %d\n", T);

      sprintf(result_file, "%s", argv[6]);
      printf("# Result file: %s\n", result_file);

      printf("# Theoretically, the critical regime is obtained by setting beta = 1. Practically, slightly larger values of the beta are required to effectively observe a critical behavior.\n");
    }

  if(dynamical_model > 0){
    //sets initial seed for random number generator
    init_genrand64((unsigned) time(NULL) * getpid());
    int i;
    int *K;       //pointer declaration
    int aa;
    int bb;
    int stop;
    int *length;
    int *Pos_connec;
    int ind;
    int pri;
    //int K =0;
    //pri =1000;
    pri =325000;
      
    //counts number of nodes
    int N = count_nodes (network_file);
      
    printf("\n\n# Total number of nodes %d\n",N);
    fflush(stdout);

    //memory allocation network
    int **bond_out = (int **)malloc((N+1)*sizeof(int *));
    bond_out[0] = (int *)malloc((N+1)*sizeof(int));
    for(i=1;i<=N;i++) bond_out[i] = (int *)malloc(1*sizeof(int));
    int **bond_in = (int **)malloc((N+1)*sizeof(int *));
    bond_in[0] = (int *)malloc((N+1)*sizeof(int));
    for(i=1;i<=N;i++) bond_in[i] = (int *)malloc(1*sizeof(int));
    //memory allocation results
    double **results = (double **)malloc((T+1)*sizeof(double *));
    for(i=1;i<=T;i++) results[i] = (double *)malloc(3*sizeof(double));
      
      
      
    //memory allocation BFDP
    //int *connec_nodes_nDoubles = (int *)calloc((N+1), sizeof(int));
    //int *connec_nodes = (int *)calloc((N+1), sizeof(int));
    //int *nodes_degrees = (int *)calloc((N+1),sizeof(int));
    //int *dist_out = (int *)malloc((N+1)*sizeof(int));
    //int *dist_in = (int *)malloc((N+1)*sizeof(int));
    //int *connec_bool = (int *)calloc((N+1), sizeof(int));
    int *avalance_nodes = (int *)calloc((N+1), sizeof(int));
     
    //reads network data and stores network data into bond
    read_edges_directed (network_file, N, bond_in, bond_out);
    if(directed!=1) make_network_symmetric (N, bond_in, bond_out);
      
      //for(int k=1;k<=10;k++){
            //printf("Bond %d ", bond_in[][k]);
      //printf("\n");
          // printf("Bond %d, %d ", bond_out[240][k], k);
     // printf("\n");
      //  }
      
      
      
    //SIS
    if(dynamical_model == 5)
      {
    double lambda = largest_eigenvalue (N, bond_in);
    printf("# Approximated epidemic threshold: lambda_c = %g\n", 1.0/lambda);
    beta = beta / lambda;
    printf("# Model parameter: lambda = %g\n", beta);
    printf("# You can change the value of the model parameter in the source code to consider non-critical dynamical regimes\n");
      }

      
    //SIR
    if(dynamical_model == 6)
      {
    double lambda = largest_nonbacktracking (N, bond_in);
    printf("# Approximated epidemic threshold: lambda_c = %g\n", 1.0/lambda);
    beta = beta / lambda;
    printf("# Model parameter: beta = %g\n", beta);
    printf("# You can change the value of the model parameter in the source code to consider non-critical dynamical regimes\n");
      }

      
    //this imposes an upper-bound to the maximal duration of the avalanches
    //double MAX_Lifetime = 10.0 * (double)N;
    double MAX_Lifetime = 1 * (double)N;

    //simulations
    printf("\n\n# Start simulations\n");
    fflush(stdout);

    //CN
    if(dynamical_model == 1){
     
        //for (int s=1; s < 222863; s++) { //1982
        //for (int s=1; s < 674110; s++) { //1997
        //for (int s=1; s < 61826; s++) { //1982
        //for (int s=1; s < 304088 ; s++) { //1982 all REFER
        //for (int s=1; s < 891631 ; s++) { //1987 all
        //for (int s=1; s < 456533 ; s++) { //1992
        //for (int s=1; s < 1561128 ; s++) { //1992 all
        //for (int s=1; s < 673773 ; s++) { //1997
        //for (int s=1; s < 949232 ; s++) { //2002
        //for (int s=1; s < 2976023; s++) { //2002
        //for (int s=1; s < 1294862; s++) { //2007
        //for (int s=1; s < 324000; s++) { //2007
        //for (int s=1; s < 324050; s++) { //2007
        //for (int s=323998; s < 326000; s++) { //2007
        for (int s=323998; s < 1816500; s++) { //2007
        //for (int s=1; s < 3000; s++) { //2007
           //KK=1;
           stop =0;
           aa =0;
           bb = 0;
           Pos_connec = &bb;
           K= &aa;
            
            int *connec_nodes_nDoubles = (int *)calloc((10*N+1), sizeof(int));
            int *connec_nodes = (int *)calloc((10*N+1), sizeof(int));
            int *nodes_degrees = (int *)calloc((N+1),sizeof(int));
            int *dist_out = (int *)calloc((N+1),sizeof(int));
            int *dist_in = (int *)calloc((N+1), sizeof(int));
            int *connec_bool = (int *)calloc((N+1), sizeof(int));
            //for(i=1;i<=10*N-1;i++) {
            //printf("Connec_nodesN  %d, %d", connec_nodes[i], i  );
            //printf("\n");
            //}
              
           snode = s;
           //s=140;
            //s=204;
           //s=50400;
           //snode =140;
            //snode =204;
          //snode = 905970;
          //snode = 50400;
          //snode = 1288471;
          //snode = 147839;
          //  snode = 672157;
          // snode = 674080;
          //snode = 674099;
          //snode = 674108;
          //snode = 1380;
          //snode = 15745;
            //snode = 83906;
            //snode = 28915;
            //snode = 28999;
               //printf(" Bool  %d, %d", connec_bool[snode], snode);
               //printf("\n");
              
              
              if(snode > pri){
              printf(",%d",snode);
                  pri=pri+1000;
              }
              
        //printf(" Snode  %d, ,%d, ,%d, %d, %d, %d", *K, N, T, KK,snode, connec_bool[s] );
        //printf("\n");
            
        //avalanche ( K, N, T, &snode, bond_in, bond_out, connec_nodes, nodes_degrees, KK, //dist_out, dist_in, connec_bool, Pos_connec);
              
       //printf(" New Avalanche1  %d, %d, %d, %d, %d, %d", *K, N, T, KK, snode, *Pos_connec );
       //printf("\n");
              
        //stop +=1000;
            
        do{
            
        if ( *Pos_connec >= KK ){
            //printf(" New AvalancheIN  %d, %d", *Pos_connec, KK);
            // printf("\n");
         KK += 10000;
           // printf(" New AvalancheIN  %d, %d", *Pos_connec, KK);
           // printf("\n");
           
           

            
         avalanche ( K, N, T, &snode, bond_in, bond_out, connec_nodes, nodes_degrees, KK, dist_out, dist_in, connec_bool, Pos_connec);
        }
         
        }while(*Pos_connec>=*K);
        
          
        //printf(" New Avalanche2  %d, %d, %d, %d, %d, %d", *K, N, T, KK, snode, *Pos_connec );
        // printf("\n");
        // if ( *Pos_connec >= 100001 ){
        //  KK += 1;//
        //  avalanche ( K, N, T, &snode, bond_in, bond_out, connec_nodes, nodes_degrees, KK, dist_out, dist_in, connec_bool, Pos_connec);
             //   }
        // printf(" New Avalanche3  %d, %d, %d, %d, %d, %d", *K, N, T, KK, snode, *Pos_connec );
        // printf("\n");
        //  if ( *Pos_connec >= 140001 ){
        //  KK += 1;
        //  avalanche ( K, N, T, &snode, bond_in, bond_out, connec_nodes, nodes_degrees, KK, dist_out, dist_in, connec_bool, Pos_connec);
                   //     }
             //ind:Measures the length of connec_nodes array, i.e. avalanche nodes with duplicates
        ind = 1;
        length = (int *)1;
          //*ptr = 20;
            
            //IMPORTANT: CORRECT LENGTH FUNCTION AFTER
                         // printf("%d", *ptr);
        length = connected_nodes_length(connec_nodes, ind, length);
        // printf(" Out length %d, %d", length, ind  );
        //printf("\n");
            
        connec_nodes_no_duplicates(connec_nodes, connec_nodes_nDoubles, length, avalance_nodes, s); //snode if only on iteration
        
        KK=0;
        //for (int f=1; f < 2; f++) {
            //printf( "SIZE2, %d, %d, %d", avalance_nodes[s], s, N); //take snode //instead of s for a single node
              //printf("\n");
       // }
       free(connec_nodes_nDoubles);
       free(connec_nodes);
       free(nodes_degrees);
       free(dist_out);
       free(dist_in);
       free(connec_bool);
       }
    }
        
        
        //writes results on file for dynamical model CN
        if ( dynamical_model == 1 ){
        FILE *f;
        f = fopen(result_file, "w");//fprintf(f, "%d %d  \n",avalance_nodes[snode],snode);
        
                
            for(i=1;i<=N;i++){
                
             if( avalance_nodes[i] == 0){ fprintf(f, "%d %d  \n", 1,i); }
             else{ fprintf(f, "%d %d  \n",avalance_nodes[i],i); }
                
            }
            
            
        //for(i=1;i<=N;i++) fprintf(f, "%d   \n",avalance_nodes[i]);
        fclose(f);
         
        }
      
      
      
    //CIC
    if(dynamical_model == 1){
      multiple_simulations_directed_CIC (N, bond_in, bond_out, mu, MAX_Lifetime, T, results);
    }

    //VOT
    if(dynamical_model == 2){
      multiple_simulations_directed_VOTER (N, bond_in, bond_out, MAX_Lifetime, T, results);
    }

    //INV
    if(dynamical_model == 3){
      multiple_simulations_directed_INV_PROC (N, bond_in, bond_out, MAX_Lifetime, T, results);
    }

     //LID
    if(dynamical_model == 4){
      multiple_simulations_directed_LINK_DYNAMICS (N, bond_in, bond_out, MAX_Lifetime, T, results);
    }


     //SIS
    if(dynamical_model == 5){
      multiple_simulations_directed_SIS (N, bond_in, bond_out, beta, MAX_Lifetime, T, results);
     }


    //SIR
    if(dynamical_model == 6){
      multiple_simulations_directed_SIR (N, bond_in, bond_out, beta, MAX_Lifetime, T, results);
     }

    //COP
    if(dynamical_model == 7){
      multiple_simulations_directed_COP (N, bond_in, bond_out, beta, MAX_Lifetime, T, results);
     }

      
    printf("# End simulations\n\n\n");
    fflush(stdout);


    //writes results on file for all dynamical models except CN
    if ( dynamical_model != 1 ){
    FILE *f;
    f = fopen(result_file, "w");
    for(i=1;i<=T;i++) fprintf(f, "%g %g %g %g\n",results[i][0],results[i][1],results[i][2],results[i][3] );
    fclose(f);
    }
     
   
    //for(i=1;i<=T;i++) fprintf(f, "%f %f %f %f\n",results[i][0],results[i][1],results[i][2],results[i][3] );
      
    //for(i=1;i<=T;i++) fprintf(f, "%a %a %a %a\n", results[i][0],results[i][1],results[i][2],results[i][3] );
      //fclose(f);

    //memory release
    for(i=0;i<=N;i++) free(bond_in[i]);
    free(bond_in);
    for(i=0;i<=N;i++) free(bond_out[i]);
    free(bond_out);
    for(i=1;i<=T;i++) free(results[i]);
    free(results);
    //free(ind);
    //for(i=0;i<=N;i++) free(connec_nodes[i]);
    //free(connec_nodes);
    //free(connec_nodes_nDoubles);
    //free(nodes_degrees);
    //free(dist_out);
    //free(dist_in);
    free(avalance_nodes);
    
    //free(var);
         
   // for(i=0;i<=N;i++) free(dist_in[i]);
   // free(dist_in);
   // for(i=0;i<=N;i++) free(dist_out[i]);
   // free(dist_out);
   //for(i=0;i<=6;i++) free(connec_nodes[i]);
  //free(connec_nodes);
    
    //////////////////

  }

  else{

     printf("\n\n#ERROR : Please run the program as\n");
     printf("# ./avalanche_dynamics model param dir edge_list_file number_simulations result_file\n");

      printf("\n# \"model\" specifies the dynamical model used for avalanche dynamics\n");
      printf("# available options are:\n");
      printf("# CIC for Competition-Induced Criticality Model\n");
      printf("# VOT for Voter Model\n");
      printf("# INV for Invasion Process\n");
      printf("# LID for Link Dynamics\n");
      printf("# SIS for Susceptible-Infected-Susceptible Model\n");
      printf("# SIR for Susceptible-Infected-Recovered Model\n");
      printf("# COP for Contact Process\n");
      printf("# CN for Connected Nodes\n");


       printf("\n# \"param\" specifies the value of the model parameter used in the simulations. The value of this parameter serves to change the dynamical regime, i.e., subcritical, critical or supercritical, of the model. The value of the parameter that put the system in the critical state generally depends on the dynamical process and the underlying network.\n");

      printf("\n# \"dir\" specifies if the network is directed or undirected. Set equal to 1 for directed, or any other value for undirected\n");

      printf("\n# \"edge_list_file\" specifies the name of the file containing the list of edges of the network\n");

      printf("\n# \"number_simulations\" is an integer number that indicates the total number of avalanches that you want to simulate\n");

      printf("\n# \"result_file\" specifies the name of the file where the program will output the results of the simulations\n\n\n");

  }

  return 0;
}
