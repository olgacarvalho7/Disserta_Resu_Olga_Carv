//
//  sir_model.c
//  avalanche_code
//
//  Created by Olga Carvalho on 07/01/2022.
//  Copyright © 2022 Olga Carvalho. All rights reserved.
//

#include "sir_model.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>
#include <time.h>
#include "mt64.h"
#include "basic_functions.h"


void multiple_simulations_directed_SIR (int N, int **bond_in, int **bond_out, double beta, double MAX_Lifetime, int T, double **results)
{
 
  int t;
  int i;
  int M = 0;
  for(i=1;i<=N;i++) M+=bond_out[0][i];
  

  //
  //memory allocation
  int *infected = (int *)malloc((N+1)*sizeof(int));
  int **active_links = (int **)malloc(2*sizeof(int*));
  active_links[0] = (int *)malloc((M+1)*sizeof(int));
  active_links[1] = (int *)malloc((M+1)*sizeof(int));

  int *nodes = (int *)malloc((N+1)*sizeof(int));
  int **rev_bond_in = (int **)malloc((N+1)*sizeof(int *));
  rev_bond_in[0] = (int *)malloc((N+1)*sizeof(int));
  for(i=1;i<=N;i++) rev_bond_in[i] = (int *)malloc((bond_in[0][i]+1)*sizeof(int));
  int **rev_bond_out = (int **)malloc((N+1)*sizeof(int *));
  rev_bond_out[0] = (int *)malloc((N+1)*sizeof(int));
  for(i=1;i<=N;i++) rev_bond_out[i] = (int *)malloc((bond_out[0][i]+1)*sizeof(int));
  //


  int r_node, control;
  int kk = 0;
  for(t=1;t<=T;t++)
    {
    again:
      r_node = (int)(genrand64_real3()*(double)N)+1;
      if(r_node > N) r_node = 1;
      if(bond_in[0][r_node]==0) goto again;
  

      //initial condition
      infected[0] = 1;
      infected[1] = r_node;
      ///

      
      full_update_variables_directed_SIR (N, bond_in, bond_out, infected, nodes, active_links, rev_bond_in, rev_bond_out);
      

      results[t][0] = 1.0;
      results[t][1] = 0.0;
      results[t][2] = 0.0;
      results[t][3] = r_node;

      control = -1;
      
      if(t>kk)
    {
      printf("%d of %d\n",t,T); fflush(stdout);
      kk += (int)(0.05*(double)T);
    }

      while(control< 0 &&  infected[0] > 0 && results[t][1] < MAX_Lifetime)
    {

      single_update_results_directed_SIR (N, bond_in, bond_out, infected, nodes, active_links, rev_bond_in, rev_bond_out, 1.0, beta, results[t]);

    }

    }

  //memory release
  free(infected);
  free(nodes);
  free(active_links[0]);
  free(active_links[1]);
  free(active_links);
  for(i=0;i<=N;i++) free(rev_bond_in[i]);
  free(rev_bond_in);
  for(i=0;i<=N;i++) free(rev_bond_out[i]);
  free(rev_bond_out);
  //

}









void full_update_variables_directed_SIR (int N, int **bond_in, int **bond_out, int *infected, int *nodes, int **active_links, int **rev_bond_in, int **rev_bond_out)
{
  int i, j, m, n, k;
 
  for(i=1;i<=N;i++) nodes[i] = -1;
  for(i=1;i<=N;i++)
    {
      rev_bond_in[0][i] = bond_in[0][i];
      for(j=1;j<=bond_in[0][i];j++) rev_bond_in[i][j]=-1;
      rev_bond_out[0][i] = bond_out[0][i];
      for(j=1;j<=bond_out[0][i];j++) rev_bond_out[i][j]=-1;
    }

  for(m=1;m<=infected[0];m++)
    {
      n = infected[m];
      nodes[n] = m;
    }

  active_links[0][0] = 0;
  for(m=1;m<=infected[0];m++)
    {
      n = infected[m];
      for(j=1;j<=bond_out[0][n];j++)
    {
      i = bond_out[n][j];
      if(nodes[i]<0)
        {
          active_links[0][0]++;

          
          active_links[0][active_links[0][0]] = n;
          active_links[1][active_links[0][0]] = i;
          
          rev_bond_out[n][j] =  active_links[0][0];
          

          k = find_neighbor(i, n, bond_in);
          rev_bond_in[i][k] =  active_links[0][0];
          

        }
    }
    }
 
}







void single_update_results_directed_SIR (int N, int **bond_in, int **bond_out, int *infected, int *nodes, int **active_links, int **rev_bond_in, int **rev_bond_out, double rho, double lambda, double *results)
{

  double p1 = genrand64_real3();


  double alpha_d = (double)infected[0] * rho;
  double alpha_u = (double)active_links[0][0] * lambda;
  double norm = alpha_u + alpha_d;


  //double prob_d = alpha_d / norm;
  double prob_u = alpha_u / norm;
  
  //printf("#%d : %g %g\n",infected[0],prob_u,prob_d);


  //printf("%d %d : %g %g %g\n",infected[0],active_links[0][0],norm,prob_d,prob_u);


  if (p1 < prob_u) {
    //infect a node
    infect_a_node_directed_SIR (N, bond_in, bond_out, infected, nodes, active_links, rev_bond_in, rev_bond_out);
    results[0] += 1;
  }



  else
    {
      //cure a node
      cure_a_node_directed_SIR (N, bond_in, bond_out, infected, nodes, active_links, rev_bond_in, rev_bond_out);
    }


  results[1] -= log(genrand64_real3()) / norm;
  results[2] += 1.0 / norm;
  

}






void cure_a_node_directed_SIR (int N, int **bond_in, int **bond_out, int *infected, int *nodes, int **active_links, int **rev_bond_in, int **rev_bond_out)
{

  int n, m, j, a, q1, q2, l1, l2, l;


  n = (int)(genrand64_real3() * (double)infected[0] ) + 1;
  if (n > infected[0] ) n =1;

  m = infected[n];


  //printf("Cure node %d\n",m);


  //update infected and nodes
  infected[n] = infected[infected[0]];
  nodes[infected[infected[0]]] = n;
  infected[0] --;
  nodes[m] = 100;


  //update active_links and rev_bond
  //remove active edges


  for(j=1;j<=bond_out[0][m];j++)
    {
      a = rev_bond_out[m][j];

      if (a > 0)
    {

      //printf("remove edge %d -- %d: %d\n",m,bond[m][j],a);

      q1 = active_links[0][active_links[0][0]];
      q2 = active_links[1][active_links[0][0]];


      //printf("(%d -- %d)\n",q1,q2);
      
      active_links[0][a] = q1;
      active_links[1][a] = q2;

      l1 = find_neighbor(q1, q2, bond_out);
      rev_bond_out[q1][l1] = a;
      l2 = find_neighbor(q2, q1, bond_in);
      rev_bond_in[q2][l2] = a;
      
    
      rev_bond_out[m][j]= -1;
      l = find_neighbor(bond_out[m][j], m, bond_in);
      rev_bond_in[bond_out[m][j]][l] = -1;
      active_links[0][0]--;

    }
    }


  /*
  //DIFFERENCE WITH RESPECT TO SIS
  //add active edges
  for(j=1;j<=bond_in[0][m];j++)
    {
     
      v = bond_in[m][j];

      if (nodes[v]>0)
    {

      //printf("add edge %d -- %d\n",m,bond[m][j]);

      active_links[0][0]++;



      active_links[0][active_links[0][0]] = v;
      active_links[1][active_links[0][0]] = m;

      
      rev_bond_in[m][j] = active_links[0][0];

      l2 = find_neighbor(v, m, bond_out);
      rev_bond_out[v][l2] = active_links[0][0];
        

    }

    }
  ///////////
  */


}






void infect_a_node_directed_SIR (int N, int **bond_in, int **bond_out, int *infected, int *nodes, int **active_links, int **rev_bond_in, int **rev_bond_out)
{

  int l, n1, n2, m, l1, l2, q1, q2, j, a, v;


  l = (int)(genrand64_real3() * (double)active_links[0][0] ) + 1;
  if (l > active_links[0][0] ) l =1;

  n1 = active_links[0][l];
  n2 = active_links[1][l];


  m = n2;
  if(nodes[n1]<0) m = n1;
  

  if (nodes[n1] * nodes[n2] > 0) printf("Error\n\n");

  //printf("Infect node %d\n",m);



  //update infected and nodes
  infected[0] ++;
  infected[infected[0]] = m;
  nodes[m] = infected[0];


  //update active_links and rev_bond

  //remove active edges
  for(j=1;j<=bond_in[0][m];j++)
    {
      a = rev_bond_in[m][j];
       if (a > 0)
    {

      //printf("remove edge %d -- %d: %d\n",m,bond[m][j], a);

      q1 = active_links[0][active_links[0][0]];
      q2 = active_links[1][active_links[0][0]];


      //printf("(%d -- %d)\n",q1,q2);
      
      active_links[0][a] = q1;
      active_links[1][a] = q2;
    
      l1 = find_neighbor(q1, q2, bond_out);
      rev_bond_out[q1][l1] = a;
      l2 = find_neighbor(q2, q1, bond_in);
      rev_bond_in[q2][l2] = a;
      

      rev_bond_in[m][j]=-1;
      l = find_neighbor(bond_in[m][j], m, bond_out);
      rev_bond_out[bond_in[m][j]][l] = -1;

      active_links[0][0]--;
    }
      
    }


 //add active edges
  for(j=1;j<=bond_out[0][m];j++)
    {
     
      v = bond_out[m][j];

      if (nodes[v]<0)
    {

      //printf("add edge %d -- %d\n",m,bond[m][j]);

      active_links[0][0]++;
      
      active_links[0][active_links[0][0]] = m;
      active_links[1][active_links[0][0]] = v;
      
        
      rev_bond_out[m][j] = active_links[0][0];
      
      l2 = find_neighbor(v, m, bond_in);
      rev_bond_in[v][l2] = active_links[0][0];
        

    }

    }



}





////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////


////
//FASTER VERSION
///


////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////


void multiple_simulations_directed_SIR_faster (int N, int **bond_in, int **bond_out, double beta, double MAX_Lifetime, int T, double **results)
{
 
  int t;
  int i;
  int M = 0;
  for(i=1;i<=N;i++) M+=bond_out[0][i];
  

  //
  //memory allocation
  int *infected = (int *)malloc((N+1)*sizeof(int));
  int *recovered = (int *)malloc((N+1)*sizeof(int));
  int **active_links = (int **)malloc(2*sizeof(int*));
  active_links[0] = (int *)malloc((M+1)*sizeof(int));
  active_links[1] = (int *)malloc((M+1)*sizeof(int));

  int *nodes = (int *)malloc((N+1)*sizeof(int));
  int **rev_bond_in = (int **)malloc((N+1)*sizeof(int *));
  rev_bond_in[0] = (int *)malloc((N+1)*sizeof(int));
  for(i=1;i<=N;i++) rev_bond_in[i] = (int *)malloc((bond_in[0][i]+1)*sizeof(int));
  int **rev_bond_out = (int **)malloc((N+1)*sizeof(int *));
  rev_bond_out[0] = (int *)malloc((N+1)*sizeof(int));
  for(i=1;i<=N;i++) rev_bond_out[i] = (int *)malloc((bond_out[0][i]+1)*sizeof(int));
  //


  //intitialize all variables only at the beginning
  full_update_variables_directed_SIR_faster (N, bond_in, bond_out, infected, recovered, nodes, active_links, rev_bond_in, rev_bond_out);
      


  int r_node, control;
  int kk = 0;
  for(t=1;t<=T;t++)
    {
    again:
      r_node = (int)(genrand64_real3()*(double)N)+1;
      if(r_node > N) r_node = 1;
      if(bond_in[0][r_node]==0) goto again;


      
      partial_reset_variables_directed_SIR_faster (N, r_node, bond_in, bond_out, infected, recovered, nodes, active_links, rev_bond_in, rev_bond_out);


      

 
      results[t][0] = 1.0;
      results[t][1] = 0.0;
      results[t][2] = 0.0;
      results[t][3] = r_node;

      control = -1;
      
      if(t>kk)
    {
      printf("%d of %d\n",t,T); fflush(stdout);
      kk += (int)(0.05*(double)T);
    }

      while(control< 0 &&  infected[0] > 0 && results[t][1] < MAX_Lifetime)
    {

      single_update_results_directed_SIR_faster (N, bond_in, bond_out, infected, recovered, nodes, active_links, rev_bond_in, rev_bond_out, 1.0, beta, results[t]);

    }


      //printf("%d %g\n",recovered[0], results[t][0]);

    }

  //memory release
  free(infected);
  free(recovered);
  free(nodes);
  free(active_links[0]);
  free(active_links[1]);
  free(active_links);
  for(i=0;i<=N;i++) free(rev_bond_in[i]);
  free(rev_bond_in);
  for(i=0;i<=N;i++) free(rev_bond_out[i]);
  free(rev_bond_out);
  //

}




void full_update_variables_directed_SIR_faster (int N, int **bond_in, int **bond_out, int *infected, int *recovered, int *nodes, int **active_links, int **rev_bond_in, int **rev_bond_out)
{
  int i, j, m, n, k;
 
  for(i=1;i<=N;i++) nodes[i] = -1;
  for(i=1;i<=N;i++)
    {
      rev_bond_in[0][i] = bond_in[0][i];
      for(j=1;j<=bond_in[0][i];j++) rev_bond_in[i][j]=-1;
      rev_bond_out[0][i] = bond_out[0][i];
      for(j=1;j<=bond_out[0][i];j++) rev_bond_out[i][j]=-1;
    }

  recovered[0] = 0;
  for(i=1;i<=N;i++) recovered[i] = -1;

  for(m=1;m<=infected[0];m++)
    {
      n = infected[m];
      nodes[n] = m;
    }

  active_links[0][0] = 0;
  for(m=1;m<=infected[0];m++)
    {
      n = infected[m];
      for(j=1;j<=bond_out[0][n];j++)
    {
      i = bond_out[n][j];
      if(nodes[i]<0)
        {
          active_links[0][0]++;

          
          active_links[0][active_links[0][0]] = n;
          active_links[1][active_links[0][0]] = i;
          
          rev_bond_out[n][j] =  active_links[0][0];
          

          k = find_neighbor(i, n, bond_in);
          rev_bond_in[i][k] =  active_links[0][0];
          

        }
    }
    }
 
}







void partial_reset_variables_directed_SIR_faster (int N, int r_node, int **bond_in, int **bond_out, int *infected, int *recovered, int *nodes, int **active_links, int **rev_bond_in, int **rev_bond_out)
{
  int i, j, m, n, k;


  //partial reset
  
  while(infected[0]>0)
    {
      n = infected[1];
      nodes[n] = -1;
      infected[1] = infected[infected[0]];
      infected[0]--;
    }

  while(recovered[0]>0)
    {
      n = recovered[1];
      nodes[n] = -1;
      recovered[1] = recovered[recovered[0]];
      recovered[0]--;
    }

  while(active_links[0][0]>0)
    {
      n = active_links[0][1];
      m = active_links[1][1];

      k = find_neighbor(n, m, bond_out);
      rev_bond_out[n][k] =  -1;

      k = find_neighbor(m, n, bond_in);
      rev_bond_in[m][k] =  -1;

      active_links[0][1] = active_links[0][active_links[0][0]];
      active_links[1][1] = active_links[1][active_links[0][0]];
      active_links[0][0] --;
    }



  //
  //initi variables

  //initial condition
  infected[0] = 1;
  infected[1] = r_node;
  ///
   
  ///
  for(m=1;m<=infected[0];m++)
    {
      n = infected[m];
      nodes[n] = m;
    }

  active_links[0][0] = 0;
  for(m=1;m<=infected[0];m++)
    {
      n = infected[m];
      for(j=1;j<=bond_out[0][n];j++)
    {
      i = bond_out[n][j];
      if(nodes[i]<0)
        {
          active_links[0][0]++;

          
          active_links[0][active_links[0][0]] = n;
          active_links[1][active_links[0][0]] = i;
          
          rev_bond_out[n][j] =  active_links[0][0];
          

          k = find_neighbor(i, n, bond_in);
          rev_bond_in[i][k] =  active_links[0][0];
          

        }
    }
    }
 
}






void single_update_results_directed_SIR_faster (int N, int **bond_in, int **bond_out, int *infected, int *recovered, int *nodes, int **active_links, int **rev_bond_in, int **rev_bond_out, double rho, double lambda, double *results)
{

  double p1 = genrand64_real3();


  double alpha_d = (double)infected[0] * rho;
  double alpha_u = (double)active_links[0][0] * lambda;
  double norm = alpha_u + alpha_d;


  //double prob_d = alpha_d / norm;
  double prob_u = alpha_u / norm;
  
  //printf("#%d : %g %g\n",infected[0],prob_u,prob_d);


  //printf("%d %d : %g %g %g\n",infected[0],active_links[0][0],norm,prob_d,prob_u);


  if (p1 < prob_u) {
    //infect a node
    infect_a_node_directed_SIR_faster (N, bond_in, bond_out, infected, recovered, nodes, active_links, rev_bond_in, rev_bond_out);
    results[0] += 1;
  }



  else
    {
      //cure a node
      cure_a_node_directed_SIR_faster (N, bond_in, bond_out, infected, recovered, nodes, active_links, rev_bond_in, rev_bond_out);
    }


  results[1] -= log(genrand64_real3()) / norm;
  results[2] += 1.0 / norm;
  

}






void cure_a_node_directed_SIR_faster (int N, int **bond_in, int **bond_out, int *infected, int *recovered, int *nodes, int **active_links, int **rev_bond_in, int **rev_bond_out)
{

  int n, m, j, a, q1, q2, l1, l2, l;


  n = (int)(genrand64_real3() * (double)infected[0] ) + 1;
  if (n > infected[0] ) n =1;

  m = infected[n];


  //printf("Cure node %d\n",m);


  //update infected and nodes
  infected[n] = infected[infected[0]];
  nodes[infected[infected[0]]] = n;
  infected[0] --;
  nodes[m] = 100;
  recovered[0]++;
  recovered[recovered[0]] = m;


  //update active_links and rev_bond
  //remove active edges


  for(j=1;j<=bond_out[0][m];j++)
    {
      a = rev_bond_out[m][j];

      if (a > 0)
    {

      //printf("remove edge %d -- %d: %d\n",m,bond[m][j],a);

      q1 = active_links[0][active_links[0][0]];
      q2 = active_links[1][active_links[0][0]];


      //printf("(%d -- %d)\n",q1,q2);
      
      active_links[0][a] = q1;
      active_links[1][a] = q2;

      l1 = find_neighbor(q1, q2, bond_out);
      rev_bond_out[q1][l1] = a;
      l2 = find_neighbor(q2, q1, bond_in);
      rev_bond_in[q2][l2] = a;
      
    
      rev_bond_out[m][j]= -1;
      l = find_neighbor(bond_out[m][j], m, bond_in);
      rev_bond_in[bond_out[m][j]][l] = -1;
      active_links[0][0]--;

    }
    }


  /*
  //DIFFERENCE WITH RESPECT TO SIS
  //add active edges
  for(j=1;j<=bond_in[0][m];j++)
    {
     
      v = bond_in[m][j];

      if (nodes[v]>0)
    {

      //printf("add edge %d -- %d\n",m,bond[m][j]);

      active_links[0][0]++;



      active_links[0][active_links[0][0]] = v;
      active_links[1][active_links[0][0]] = m;

      
      rev_bond_in[m][j] = active_links[0][0];

      l2 = find_neighbor(v, m, bond_out);
      rev_bond_out[v][l2] = active_links[0][0];
        

    }

    }
  ///////////
  */


}






void infect_a_node_directed_SIR_faster (int N, int **bond_in, int **bond_out, int *infected, int *recovered, int *nodes, int **active_links, int **rev_bond_in, int **rev_bond_out)
{

  int l, n1, n2, m, l1, l2, q1, q2, j, a, v;


  l = (int)(genrand64_real3() * (double)active_links[0][0] ) + 1;
  if (l > active_links[0][0] ) l =1;

  n1 = active_links[0][l];
  n2 = active_links[1][l];


  m = n2;
  if(nodes[n1]<0) m = n1;
  

  if (nodes[n1] * nodes[n2] > 0) printf("Error\n\n");

  //printf("Infect node %d\n",m);



  //update infected and nodes
  infected[0] ++;
  infected[infected[0]] = m;
  nodes[m] = infected[0];


  //update active_links and rev_bond

  //remove active edges
  for(j=1;j<=bond_in[0][m];j++)
    {
      a = rev_bond_in[m][j];
       if (a > 0)
    {

      //printf("remove edge %d -- %d: %d\n",m,bond[m][j], a);

      q1 = active_links[0][active_links[0][0]];
      q2 = active_links[1][active_links[0][0]];


      //printf("(%d -- %d)\n",q1,q2);
      
      active_links[0][a] = q1;
      active_links[1][a] = q2;
    
      l1 = find_neighbor(q1, q2, bond_out);
      rev_bond_out[q1][l1] = a;
      l2 = find_neighbor(q2, q1, bond_in);
      rev_bond_in[q2][l2] = a;
      

      rev_bond_in[m][j]=-1;
      l = find_neighbor(bond_in[m][j], m, bond_out);
      rev_bond_out[bond_in[m][j]][l] = -1;

      active_links[0][0]--;
    }
      
    }


 //add active edges
  for(j=1;j<=bond_out[0][m];j++)
    {
     
      v = bond_out[m][j];

      if (nodes[v]<0)
    {

      //printf("add edge %d -- %d\n",m,bond[m][j]);

      active_links[0][0]++;
      
      active_links[0][active_links[0][0]] = m;
      active_links[1][active_links[0][0]] = v;
      
      rev_bond_out[m][j] = active_links[0][0];
      
      l2 = find_neighbor(v, m, bond_in);
      rev_bond_in[v][l2] = active_links[0][0];
        
    }

    }

}
