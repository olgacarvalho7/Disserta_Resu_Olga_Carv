//
//  sis_model.h
//  avalanche_code
//
//  Created by Olga Carvalho on 07/01/2022.
//  Copyright © 2022 Olga Carvalho. All rights reserved.
//

#ifndef sis_model_h
#define sis_model_h

#include <stdio.h>
void multiple_simulations_directed_SIS (int N, int **bond_in, int **bond_out, double beta, double MAX_Lifetime, int T, double **results);
void full_update_variables_directed_SIS (int N, int **bond_in, int **bond_out, int *infected, int *nodes, int **active_links, int **rev_bond_in, int **rev_bond_out);
void single_update_results_directed_SIS (int N, int **bond_in, int **bond_out, int *infected, int *nodes, int **active_links, int **rev_bond_in, int **rev_bond_out, double rho, double lambda, double *results);
void cure_a_node_directed_SIS (int N, int **bond_in, int **bond_out, int *infected, int *nodes, int **active_links, int **rev_bond_in, int **rev_bond_out);
void infect_a_node_directed_SIS (int N, int **bond_in, int **bond_out, int *infected, int *nodes, int **active_links, int **rev_bond_in, int **rev_bond_out);



//////

void multiple_simulations_directed_SIS_faster (int N, int **bond_in, int **bond_out, double beta, double MAX_Lifetime, int T, double **results);
void partial_reset_variables_directed_SIS_faster (int N, int r_node, int **bond_in, int **bond_out, int *infected, int *nodes, int **active_links, int **rev_bond_in, int **rev_bond_out);
#endif /* sis_model_h */
