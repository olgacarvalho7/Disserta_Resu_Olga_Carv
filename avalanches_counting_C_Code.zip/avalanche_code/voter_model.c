#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>
#include <time.h>
#include "mt64.h"
#include "basic_functions.h"
#include "voter_model.h"



void initial_reset_network_directed_VOTER (int N, int *state, int *infected, int *pos_infected, int *frontier, int *pos_frontier)
{

  int j;

  /////////
  for(j=1;j<=N;j++)
    {
      state[j] = 0;
      infected[j] = -1;
      pos_infected[j] = -1;
      frontier[j] = -1;
      pos_frontier[j] = -1;
    }
  infected[0] = 0;
  frontier[0] = 0;
  ///////
  
}


void init_state_network_directed_VOTER (int N, int **bond_in, int **bond_out,  int node, int *state, int *infected, int *pos_infected, int *frontier, int *pos_frontier)
{

  int j, n;
  
  while(infected[0]>0)
    {
      n = infected[1];
      remove_from_set (infected, pos_infected, n);
      state[n] = 0;
    }

  while(frontier[0]>0)
    {
      n = frontier[1];
      remove_from_set (frontier, pos_frontier, n);
      state[n] = 0;
    }

  
  add_to_set (infected, pos_infected, node);
  state[node] = 1;
  
  for(j=1;j<=bond_out[0][node];j++) 
    {
      n = bond_out[node][j];
      if(state[n] ==0){
	add_to_set (frontier, pos_frontier, n);
	state[n] = 2;
      }
    }

}

/////////



void multiple_simulations_directed_VOTER (int N, int **bond_in, int **bond_out, double MAX_Lifetime, int T, double **results)
{

  int t;

  //memory allocation
  int *state = (int *)malloc((N+1)*sizeof(int));
  int *infected = (int *)malloc((N+1)*sizeof(int));
  int *pos_infected = (int *)malloc((N+1)*sizeof(int));
  int *frontier = (int *)malloc((N+1)*sizeof(int));
  int *pos_frontier = (int *)malloc((N+1)*sizeof(int));
  //



  initial_reset_network_directed_VOTER (N, state, infected, pos_infected, frontier, pos_frontier);
  

  int r_node, control;
  int kk = 0;
  for(t=1;t<=T;t++)
    {



      if(t>kk)
        {
          printf("%d of %d\n",t,T); fflush(stdout);
          kk += (int)(0.05*(double)T);
        }




    again:
      r_node = (int)(genrand64_real3()*(double)N)+1;
      if(r_node > N) r_node = 1;
      if(bond_in[0][r_node]==0) goto again;

      init_state_network_directed_VOTER (N, bond_in, bond_out, r_node, state, infected, pos_infected, frontier, pos_frontier);
      
  

      results[t][0] = 1.0;
      results[t][1] = 0.0;
      results[t][2] = 0.0;


      control = -1;

      while(control< 0 &&  infected[0] > 0 && results[t][1] < MAX_Lifetime)
	{
	  single_step_directed_VOTER (N, bond_in, bond_out, state, infected, pos_infected, frontier, pos_frontier, results[t]);


	  



	  if(infected[0] == N) 
	    {
	      control = 100;
	      results[t][0] = -results[t][0];
	    }

	}

    }

  //memory release
  free(state);
  free(infected);
  free(pos_infected);
  free(frontier);
  free(pos_frontier);
  //

}






void single_step_directed_VOTER (int N, int **bond_in, int **bond_out, int *state, int *infected, int *pos_infected, int *frontier, int *pos_frontier, double *results)
{

  double norm, rate1, rate2;
  rate1 = (double)infected[0];
  rate2 = (double)frontier[0];
  norm = rate1 + rate2;


  results[1] -= log(genrand64_real3()) / norm;
  results[2] += (double)(ceil(log(1.0-genrand64_real3()) / log(1.0-norm/(double)N))) / (double)N;



  double p = genrand64_real3();
 
  int v, node, j, n, m, control, change, neighbor;

  ///////////////////////////
  if (p <= rate1 / norm)
    {
            
      node =  random_selection_from_set (infected);

      if(bond_in[0][node] > 0)
	{


	  v = (int)(genrand64_real3()*(double)bond_in[0][node]) + 1;
	  if (v>bond_in[0][node]) v = 1;
	  neighbor = bond_in[node][v];
	  change = 0;


	  
	  
	  if(state[neighbor] == 1) 
	    {
	      results[0] += 1.0; //popularity increase
	    }



	  if(state[neighbor] == 0 || state[neighbor] == 2) 
	    {
	      remove_from_set (infected, pos_infected, node);
	      state[node] = 0;
	      change = 1;
	    }
	  


	  if(change > 0)
	    {

	      //
	      control = 0;
	      for(j=1;j<=bond_in[0][node];j++)
		{
		  n = bond_in[node][j];
		  if (state[n] == 1) control = 1;
		}
	      if(control>0)
		{
		  state[node] = 2;
		  add_to_set(frontier, pos_frontier, node);
		}
	      
	      
	      //check if neighbors change state
	      for(j=1;j<=bond_out[0][node];j++)
		{
		  n = bond_out[node][j];
		  if (state[n] == 2)
		    {
		      control = 0;
		      for(v=1;v<=bond_in[0][n];v++)
			{
			  m = bond_in[n][v];
			  if(state[m] == 1) control = 1;
			}
		      if(control == 0)
			{
			  remove_from_set (frontier, pos_frontier, n);
			  state[n] = 0;
			}     
		    }
		
		}
	      
	    }
	  
	}
    }




  ///////////////////////////
  if (p > rate1 / norm)
    {
            
      node =  random_selection_from_set (frontier);
      if(bond_in[0][node]>0){
	
	v = (int)(genrand64_real3()*(double)bond_in[0][node]) + 1;
	if (v>bond_in[0][node]) v = 1;
	neighbor = bond_in[node][v];
	change = 0;
	

	//printf("B) %d <= %d\n",node, n);

	//if(state[neighbor] == 0) //nothing happens
	//if(state[neighbor] == 2) //nothing happens
	
	if(state[neighbor] == 1) 
	  {
	    results[0] += 1.0; //popularity increase
	    change = 1;
	    
	    remove_from_set (frontier, pos_frontier, node);
	    add_to_set (infected, pos_infected, node);
	    state[node] = 1;

	  }



	if(change > 0)
	  {
	    
	    //check if neighbors change state
	    for(j=1;j<=bond_out[0][node];j++)
	      {
		n = bond_out[node][j];
		if (state[n] == 0)
		  {
		    add_to_set (frontier, pos_frontier, n);
		    state[n] = 2;
		  }     
	      }
	    
	  }
	
      }
    }





}





